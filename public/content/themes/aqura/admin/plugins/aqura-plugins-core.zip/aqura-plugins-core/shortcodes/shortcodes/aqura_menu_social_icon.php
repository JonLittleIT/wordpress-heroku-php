<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_menu_social_icon {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_menu_social_icon', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $icon = $href = $target = '';

		extract( shortcode_atts( array(
			'icon'         => 'fa-facebook',
			'href'         => '#',
			'target'       => '_blank',
		), $atts ) );

		$output .= '<li>
						<a href="' . esc_url( $href ) . '" target="' . esc_attr( $target ) . '">
							<i class="fa ' . esc_attr( $icon ) . '" aria-hidden="true"></i>
						</a>
					</li>';

		return $output;
	}

}
Aqura_menu_social_icon::get_instance();