<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Aqura_hero_buttons__button {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_hero_buttons__button', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_hero_buttons__button__text = $aqura_hero_buttons__button__icon = $aqura_hero_buttons__button__url = '';

		extract( shortcode_atts( array(
			'aqura_hero_buttons__button__text'	=> esc_html__( 'SoundClaoud' , 'aqura' ),
			'aqura_hero_buttons__button__icon'	=> 'fa-soundcloud',
			'aqura_hero_buttons__button__url'	=> '',
		), $atts ) );

		$output .= '<a href="' . esc_url( $aqura_hero_buttons__button__url ) . '"><i class="fa ' . esc_attr( $aqura_hero_buttons__button__icon ) . '"></i>' . esc_html( $aqura_hero_buttons__button__text ) . '</a>';

		return $output;
	}

}

Aqura_hero_buttons__button::get_instance();