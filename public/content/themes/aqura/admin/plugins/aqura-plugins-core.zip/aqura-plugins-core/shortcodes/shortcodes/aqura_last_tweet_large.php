<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_last_tweet_large {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_last_tweet_large', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_last_tweet_large__user = $aqura_last_tweet_large__user__font_size = $aqura_last_tweet_large__text__font_size = $aqura_last_tweet_large__title_text_color = '';

		extract( shortcode_atts( array(
			'aqura_last_tweet_large__user' 				=> 'Nasa',
			'aqura_last_tweet_large__image' 			=> '',
			'aqura_last_tweet_large__user__font_size' 	=> '',
			'aqura_last_tweet_large__text__font_size' 	=> '',
			'aqura_last_tweet_large__title_text_color' 	=> '',
		), $atts ) );

		$aqura_last_tweet_large__image 	= wp_get_attachment_url( $aqura_last_tweet_large__image );

		$output .= '<div class="home-twitter">';
			if ( function_exists('getTweets') && ( $aqura_last_tweet_large__user != '' ) ) {

				$aqura_tweets = getTweets($aqura_last_tweet_large__user, 1);

				foreach($aqura_tweets as $tweet) {

					if ( $tweet['text'] ) {

						$tweet_url 		= $tweet['entities']['urls'][0]['url'];
						$the_tweet 		= $tweet['text'];
						$the_tweet_date = $tweet['created_at'];
						$the_tweet_date = explode(' ', trim($the_tweet_date));
						
			$output .= '<div class="twitter-logo">';
							if ( $aqura_last_tweet_large__image != '' ) {
				$output .= '<a href="' . esc_url( $tweet_url ) . '"><img src="' . esc_url( $aqura_last_tweet_large__image ) . '" alt="' . esc_html( $aqura_last_tweet_large__user ) . '"></a>';
							}
				$output .= '<a href="' . esc_url( $tweet_url ) . '" class="user" style="color: ' . esc_attr( $aqura_last_tweet_large__title_text_color ) . ';font-size:' . esc_attr( $aqura_last_tweet_large__user__font_size ) . ';">@' . esc_html( $aqura_last_tweet_large__user ) . '</a>
						</div>
						<div class="tweet">
							<p  style="color: ' . esc_attr( $aqura_last_tweet_large__title_text_color ) . ';font-size:' . esc_attr( $aqura_last_tweet_large__text__font_size ) . ';">' . esc_html( $the_tweet ) . '</p>
						</div>';

					}
				}

			}
		$output .= '</div>';

		return $output;
	}

}
Aqura_last_tweet_large::get_instance();