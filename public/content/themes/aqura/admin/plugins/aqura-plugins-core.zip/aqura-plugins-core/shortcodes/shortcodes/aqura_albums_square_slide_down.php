<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_albums_square_slide_down {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_albums_square_slide_down', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_albums_square_slide_down__filter = $aqura_albums_square_slide_down__number = $aqura_albums_square_slide_down__title__font_size = $aqura_albums_square_slide_down__color_title = $aqura_albums_square_slide_down__color_label = $aqura_albums_square_slide_down__color_overlay = $aqura_albums_square_slide_down__cols = '';

		extract( shortcode_atts( array(
			'aqura_albums_square_slide_down__filter'			=> '',
			'aqura_albums_square_slide_down__number'			=> '9',
			'aqura_albums_square_slide_down__title__font_size'	=> '',
			'aqura_albums_square_slide_down__color_title'		=> '',
			'aqura_albums_square_slide_down__color_label'		=> '',
			'aqura_albums_square_slide_down__color_overlay' 	=> '',
			'aqura_albums_square_slide_down__cols'				=> 'three',
		), $atts ) );

		if ( $aqura_albums_square_slide_down__cols == 'one' ) {
			$aqura_albums_square_slide_down__cols = 'col-sm-12';
		} elseif ( $aqura_albums_square_slide_down__cols == 'two' ) {
			$aqura_albums_square_slide_down__cols = 'col-sm-6';
		} elseif ( $aqura_albums_square_slide_down__cols == 'three' ) {
			$aqura_albums_square_slide_down__cols = 'col-sm-4';
		} elseif ( $aqura_albums_square_slide_down__cols == 'four' ) {
			$aqura_albums_square_slide_down__cols = 'col-sm-3';
		}

		$args = array(
			'post_type'		 	=> 'albums',
			'post_status'	  	=> 'publish',
			'posts_per_page'	=> $aqura_albums_square_slide_down__number,
		);

		global $wp_query;

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$aqura_ablums_args 		= array( 'taxonomy' => 'albums-category' );
		$aqura_ablums_categories = get_categories($aqura_ablums_args);

		$output .= '<div class="album-type-3-masonry">';
						if ( $aqura_albums_square_slide_down__filter == true ) {
			$output .= '<div class="categories">
							<ul class="clearfix" data-option-key="filter">
								<li><a href="#"><i class="fa fa-filter"></i></a></li>
								<li><a href="#" class="selected" data-option-value="*">All</a></li>';
								foreach( $aqura_ablums_categories as $category ) :
								$output .= '<li>';
									$output .= '<a data-option-value=".albums-category-' . esc_attr($category->slug) . '">';
										$output .= esc_html($category->name);
									$output .= '</a>';
								$output .= '</li>';
											endforeach;
							$output .= '</ul>
						</div>';
						}
			$output .= '<div class="aqura-filter-content albums-type-3">
							<ul class="album-covers-3">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();

				$aqura_album_cover 			= rwmb_meta( 'aqura_album_options__album_cover' , array( array( 'limit' => 1 ) , 'size' => 'full' ));
				if ( $aqura_album_cover != '' ) {
				$aqura_album_cover 			= reset( $aqura_album_cover )['url'];
				}
				$aqura_album_options__bg_color_square_listing 	= rwmb_meta( 'aqura_album_options__bg_color_square_listing' );
				$aqura_album_label 			= rwmb_meta( 'aqura_album_options__album_label' );

				$aqura_album_permalink 		= get_the_permalink();

				$aqura_categories_classes = '';
				$aqura_albums_item_categories = get_the_terms( get_the_ID(), 'albums-category' );
				if( ! empty( $aqura_albums_item_categories ) ) {
					foreach( $aqura_albums_item_categories as $category ) {
						$aqura_categories_classes .= ' albums-category-' . $category->slug;
					}
				}

					$output .= '<li class="' . esc_attr( $aqura_albums_square_slide_down__cols . ' ' . $aqura_categories_classes ) . '" style="background-color: ' . esc_attr($aqura_album_options__bg_color_square_listing) . ';">
									<div class="albums-type-3-cover">
										<a href="' . get_the_permalink() . '">
											<img src="' . esc_url( $aqura_album_cover ) . '" alt="' . get_the_title() . '">
											<span class="albums-type-3-title">
												<span>
													<h3 style="color: ' . esc_attr( $aqura_albums_square_slide_down__color_title ) . '; font-size: ' . esc_attr( $aqura_albums_square_slide_down__title__font_size ) . ';">' . get_the_title() . '</h4>
													<p style="color: ' . esc_attr( $aqura_albums_square_slide_down__color_label ) . ';">' . esc_html( $aqura_album_label ) . '</p>
												</span>
											</span>
										</a>
									</div>
								</li>';

			}

		}

				$output .= '</ul>';
			$output .= '</div>';
		$output .= '</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_albums_square_slide_down::get_instance();