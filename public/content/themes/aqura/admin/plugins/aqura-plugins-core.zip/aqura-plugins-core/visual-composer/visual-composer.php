<?php
// Visual Composer Shortcodes<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }


class VC_Setup {

	protected static $instance = null;

	private function __construct() {

		if (class_exists('Vc_Manager')) {

			/**
			 * Remove other elements.
			 */
			// vc_remove_element('vc_basic_grid');
			// vc_remove_element('vc_masonry_grid');
			// vc_remove_element('vc_media_grid');
			// vc_remove_element('vc_masonry_media_grid');

			/**
			 * Setup the new shortcodes.
			 */
			
			$this->aqura_section_title();
			// $this->aqura_big_section_title();
			// $this->aqura_hero_glitch();
			$this->aqura_hero_flipping_words();
			$this->aqura_hero_tabs();
			$this->aqura_hero_buttons();
			$this->aqura_hero_buttons__button();
			$this->aqura_header_image();
			$this->aqura_albums_disks_grid();
			$this->aqura_albums_square();
			$this->aqura_albums_square_slide_down();
			$this->aqura_album_parallax();
			// $this->aqura_album_preview();
			$this->aqura_bandsintown();
			$this->aqura_event_countdown();
			$this->aqura_blog_full_width();
			$this->aqura_blog_masonry_small();
			$this->aqura_blog_masonry_style_02();
			$this->aqura_last_tweet_large();
			$this->aqura_gallery_images();
			$this->aqura_gallery_listing();
			$this->aqura_contact_informations();
			$this->aqura_contact_form();
			$this->aqura_biography();
			// $this->aqura_featured_platform();
			$this->aqura_about_me();
			$this->aqura_instagram_carousel();
			$this->aqura_instagram_carousel_small();
			// $this->aqura_parallax_square_images();
			// $this->aqura_glitch_square_images();
			// $this->aqura_scale_background();
			// $this->aqura_stores_available();

		}

	}

	public function aqura_section_title() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Section Title', 'aqura' ),
			'base' 		=> 'aqura_section_title',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__title',
					'std' 			=> esc_html__( 'AQURA' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__title__color',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Space Between Title And Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__space',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Hide - Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__underline_hide',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__underline_color',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Content - Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__underline_content',
					'description' 	=> esc_html__( 'You can use text, symbols or any kind of text content as title divider. e.g. "~".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Width - Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__underline_width',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Height - Underline', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__underline_height',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Margin Bottom', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__margin_bottom',
					'description' 	=> esc_html__( 'You can use any units. E.g. "50px".' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_big_section_title() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Section Title (Big)', 'aqura' ),
			'base' 		=> 'aqura_big_section_title',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__title',
					'std' 			=> esc_html__( 'AQURA' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__title__color',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Subtitle', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__subtitle',
					'std' 			=> esc_html__( 'Section' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Subtitle', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__subtitle__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Subtitle', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__subtitle__color',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Background Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__bg_title',
					'std' 			=> esc_html__( 'Secction Title' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Background Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__bg_title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Background Title', 'aqura' ),
					'param_name' 	=> 'aqura_big_section_title__bg_title__color',
				),
			)
		) );

	}

	public function aqura_hero_glitch() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Hero Glitch', 'aqura' ),
			'base' 		=> 'aqura_hero_glitch',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'aqura' ),
					'param_name' 	=> 'aqura_hero_glitch__image',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Shadow', 'aqura' ),
					'param_name' 	=> 'aqura_hero_glitch__shadow',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Border Radius', 'aqura' ),
					'param_name' 	=> 'aqura_hero_glitch__radius',
				),
			)
		) );

	}

	public function aqura_hero_flipping_words() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Hero (Flipping Letters)', 'aqura' ),
			'base' 		=> 'aqura_hero_flipping_words',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Flipping Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__title',
					'std' 			=> esc_html__( 'AQURA' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Flipping Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Superior Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__sup_title',
					'std' 			=> esc_html__( 'THEME - BROTHER' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Lower Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__low_title',
					'std' 			=> esc_html__( 'WORDPRES' , 'aqura' ),
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__bg_image',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Text', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__text_color',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Shadow', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__shadow',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Border Radius', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__border_radius',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Stars', 'aqura' ),
					'param_name' 	=> 'aqura_hero_flipping_words__stars',
				),
			)
		) );

	}

	public function aqura_hero_tabs() {
		vc_map( array(
			'name' 			=> esc_html__( 'Hero (Tabs)', 'aqura' ),
			'base' 			=> 'aqura_hero_tabs',
			'category' 		=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 		=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Name (First Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__first_member_name'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Profession (First Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__first_member_profession'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Anchor (First Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__first_member_anchor',
					'value' 		=> '#'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Image (First Member)', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__first_member_image'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Name (Second Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__second_member_name'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Profession (Second Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__second_member_profession'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Anchor (Second Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__second_member_anchor',
					'value' 		=> '#'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Image (Second Member)', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__second_member_image'
				),
				array(
					'type' 			=> 'textfield',
					'heading'		=> esc_html__( 'Name (Third Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__third_member_name'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Profession (Third Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__third_member_profession'
				),
				array(
					'type' 			=> 'textfield',
					'heading'		=> esc_html__( 'Anchor (Third Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__third_member_anchor',
					'value' 		=> '#'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Image (Third Member)', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__third_member_image'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Name (Fourth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fourth_member_name'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Profession (Fourth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fourth_member_profession'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Anchor (Fourth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fourth_member_anchor',
					'value' 		=> '#'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Image (Fourth Member)', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__fourth_member_image'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Name (Fifth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fifth_member_name'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Profession (Fifth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fifth_member_profession'
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Anchor (Fifth Member)', 'aqura' ),
					'param_name' 	=> 'aqura_hero_tabs__fifth_member_anchor',
					'value' 		=> '#'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Image (Fifth Member)', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__fifth_member_image'
				),
				array(
					"type" 			=> "attach_image",
					"heading" 		=> esc_html__('Main background image', 'aqura'),
					"param_name" 	=> 'aqura_hero_tabs__aqura_hero_tabs_image'
				)
			)
		) );

	}

	public function aqura_hero_buttons() {
		
		vc_map( array(
			'name' 						=> esc_html__( 'Hero (With Buttons)', 'aqura' ),
			'base' 						=> 'aqura_hero_buttons',
			'category' 					=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'content_element' 			=> true,
			'is_container' 				=> true,
			'js_view' 					=> 'VcColumnView',
			'as_parent' 				=> array('only' => 'aqura_hero_buttons__button'),
			'params' 					=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Flipping Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__title',
					'std' 			=> esc_html__( 'AQURA' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Flipping Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Superior Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__sup_title',
					'std' 			=> esc_html__( 'THEME - BROTHER' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Lower Title', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__low_title',
					'std' 			=> esc_html__( 'WORDPRES' , 'aqura' ),
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__bg_image',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Text', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__text_color',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Shadow', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__shadow',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Border Radius', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__border_radius',
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Stars', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__stars',
				),
			)
		) );

	}

	public function aqura_hero_buttons__button() {
		
		vc_map( array(
			'name' 						=> esc_html__( 'Button', 'aqura' ),
			'base' 						=> 'aqura_hero_buttons__button',
			'category' 					=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'content_element' 			=> true,
			'as_child' 					=> array('only' => 'aqura_hero_buttons'),
			'params' 					=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button Text', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__button__text',
					'std' 			=> esc_html__( 'SoundClaoud' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button Icon', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__button__icon',
					'description' 	=> esc_html__( 'A Font-Awesome class.' , 'aqura' ),
					'std'			=> 'fa-soundcloud',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button URL', 'aqura' ),
					'param_name' 	=> 'aqura_hero_buttons__button__url',
				),
			)
		) );

	}

	public function aqura_header_image() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Header Image', 'aqura' ),
			'base' 		=> 'aqura_header_image',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__title',
					'description'	=> esc_html__( 'If this field is empty the title will be the page\'s title.' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'Description', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__description',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Description', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__description__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'View More - Text', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__view_more',
					'description'	=> esc_html__( 'If this field is empty the view more text will be "View More".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - View More', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__view_more__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__bg',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Text', 'aqura' ),
					'param_name' 	=> 'aqura_header_image__color',
				),
			)
		) );

	}

	public function aqura_albums_disks_grid() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Albums Grid', 'aqura' ),
			'base' 		=> 'aqura_albums_disks_grid',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Show The Filter', 'aqura' ),
					'param_name' 	=> 'aqura_albums_disks_grid__filter',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Albums To Display', 'aqura' ),
					'param_name' 	=> 'aqura_albums_disks_grid__number',
					'std' 			=> 4,
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_albums_disks_grid__color_title',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Label', 'aqura' ),
					'param_name' 	=> 'aqura_albums_disks_grid__color_label',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_albums_disks_grid__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
					),
					'std'			=> 'four',
				),
			)
		) );

	}

	public function aqura_albums_square() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Albums Square', 'aqura' ),
			'base' 		=> 'aqura_albums_square',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Show The Filter', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__filter',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Albums To Display', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__number',
					'std' 			=> '9',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__color_title',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Label', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__color_label',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Hover Overlay', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__color_overlay',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Hover Border', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__color_border',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
					),
					'std'			=> 'three',
				),
			)
		) );

	}

	public function aqura_albums_square_slide_down() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Albums Square (Slide Down)', 'aqura' ),
			'base' 		=> 'aqura_albums_square_slide_down',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Show The Filter', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__filter',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Albums To Display', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__number',
					'std' 			=> '9',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__color_title',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Label', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__color_label',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_albums_square_slide_down__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
					),
					'std'			=> 'three',
				),
			)
		) );

	}

	public function aqura_album_parallax() {

		$aqura_albums_for_vc = query_posts(array( 
									'post_type' 		=> 'albums',
									'posts_per_page' 	=> -1,
								) );
		$aqura_albums_for_vc__show = array();
		
		foreach ($aqura_albums_for_vc as $key => $value) {

			$aqura_albums_for_vc__show[$value->post_title] = strval($value->ID);

		}

		vc_map( array(
			'name' 		=> esc_html__( 'Album (Parallax)', 'aqura' ),
			'base' 		=> 'aqura_album_parallax',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Album', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__album',
					'description' 	=> esc_html__( 'Select the album.' , 'aqura' ),
					'value'			=> $aqura_albums_for_vc__show,
				),
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'Description', 'aqura' ),
					'param_name' 	=> 'aqura_section_title__description',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__color_title',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Description', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__description__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Description', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__color_description',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Footer', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__footer__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Footer', 'aqura' ),
					'param_name' 	=> 'aqura_album_parallax__color_footer',
				),
			)
		) );

		wp_reset_query();

	}

	public function aqura_album_preview() {

		$aqura_albums_for_vc = query_posts(array( 
									'post_type' 		=> 'albums',
									'posts_per_page' 	=> -1,
								) );
		$aqura_albums_for_vc__show = array();
		
		foreach ($aqura_albums_for_vc as $key => $value) {

			$aqura_albums_for_vc__show[$value->post_title] = strval($value->ID);

		}

		vc_map( array(
			'name' 		=> esc_html__( 'Album Preview', 'aqura' ),
			'base' 		=> 'aqura_album_preview',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Album', 'aqura' ),
					'param_name' 	=> 'aqura_album_preview__album',
					'description' 	=> esc_html__( 'Select the album.' , 'aqura' ),
					'value'			=> $aqura_albums_for_vc__show,
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Tracklist Title', 'aqura' ),
					'param_name' 	=> 'aqura_album_preview__tracklist_title',
					'std'			=> esc_html__( 'Tracklist' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Albums Page URL', 'aqura' ),
					'param_name' 	=> 'aqura_album_preview__albums_url',
				),
			)
		) );

		wp_reset_query();

	}

	public function aqura_bandsintown() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Bandsintown', 'aqura' ),
			'base' 		=> 'aqura_bandsintown',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Artist', 'aqura' ),
					'param_name' 	=> 'aqura_bandsintown__artist',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Events Per Page', 'aqura' ),
					'param_name' 	=> 'aqura_bandsintown__number',
					'std' 			=> '5',
				),
			)
		) );

	}

	public function aqura_event_countdown() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Event Countdown', 'aqura' ),
			'base' 		=> 'aqura_event_countdown',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__title',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Margin Bottom - Title', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__title__margin_bottom',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__title__color',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Event Banner', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__banner',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Margin Bottom - Banner', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__banner__margin_bottom',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Link', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__link',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Beginning Date', 'aqura' ),
					'param_name' 	=> 'aqura_event_countdown__date',
					'description'	=> esc_html__( 'Year/Month/Day E.g. "2018/06/26"' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_blog_full_width() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Blog (Full Width)', 'aqura' ),
			'base' 		=> 'aqura_blog_full_width',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Number Of Articles To Display', 'aqura' ),
					'param_name' 	=> 'aqura_blog_full_width__number',
					'std'			=> '3',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_blog_full_width__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_blog_masonry_small() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Blog Masonry (Small)', 'aqura' ),
			'base' 		=> 'aqura_blog_masonry_small',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Number Of Articles To Display', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_small__number',
					'std'			=> '3',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_small__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Show The Filter', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_small__filter',
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Background Color - Article', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_small__bg',
					'std'			=> 'rgba(242, 242, 242, 0.7)',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_small__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
					),
					'std'			=> 'three',
				),
			)
		) );

	}

	public function aqura_blog_masonry_style_02() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Blog Masonry (Style 02)', 'aqura' ),
			'base' 		=> 'aqura_blog_masonry_style_02',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Number Of Articles To Display', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_style_02__number',
					'std'			=> '3',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_style_02__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Background Color - Article', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_style_02__bg',
					'std'			=> 'rgba(255, 255, 255, 1)',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_blog_masonry_style_02__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
					),
					'std'			=> 'three',
				),
			)
		) );

	}

	public function aqura_last_tweet_large() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Last Tweet (Large)', 'aqura' ),
			'base' 		=> 'aqura_last_tweet_large',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'User Name', 'aqura' ),
					'param_name' 	=> 'aqura_last_tweet_large__user',
					'std'			=> 'Nasa',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'User Image', 'aqura' ),
					'param_name' 	=> 'aqura_last_tweet_large__image',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - User', 'aqura' ),
					'param_name' 	=> 'aqura_last_tweet_large__user__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Font Size - Text', 'aqura' ),
					'param_name' 	=> 'aqura_last_tweet_large__text__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title/Text', 'aqura' ),
					'param_name' 	=> 'aqura_last_tweet_large__title_text_color',
				),
			)
		) );

	}

	public function aqura_gallery_images() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Gallery', 'aqura' ),
			'base' 		=> 'aqura_gallery_images',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'attach_images',
					'heading' 		=> esc_html__( 'Images', 'aqura' ),
					'param_name' 	=> 'aqura_gallery_images__images',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Images Gap', 'aqura' ),
					'param_name' 	=> 'aqura_gallery_images__gap',
					'std'			=> '0',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_gallery_listing() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Gallery Listing', 'aqura' ),
			'base' 		=> 'aqura_gallery_listing',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Galleries To Display', 'aqura' ),
					'param_name' 	=> 'aqura_gallery_listing__number',
					'std'			=> '6',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns - Grid', 'aqura' ),
					'param_name' 	=> 'aqura_gallery_listing__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
						esc_html__( 'Six' , 'aqura' ) 	=> 'six',
					),
					'std'			=> 'three',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Images Gap', 'aqura' ),
					'param_name' 	=> 'aqura_gallery_listing__gap',
					'std'			=> '0',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_contact_informations() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Contact Informations', 'aqura' ),
			'base' 		=> 'aqura_contact_informations',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__title',
					'std'			=> esc_html__( 'CONTACT INFORMATION' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title Size', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Address', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__address',
				),
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'Description', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__adescription',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Email', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__email',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Phone', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__phone',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Fax', 'aqura' ),
					'param_name' 	=> 'aqura_contact_informations__fax',
				),
			)
		) );

	}

	public function aqura_contact_form() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Contact Form', 'aqura' ),
			'base' 		=> 'aqura_contact_form',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_contact_form__title',
					'std'			=> esc_html__( 'CONTACT INFORMATION' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title Size', 'aqura' ),
					'param_name' 	=> 'aqura_contact_form__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Contact Form 7 ID', 'aqura' ),
					'param_name' 	=> 'aqura_contact_form__shortcode',
				),
			)
		) );

	}

	public function aqura_biography() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Biography', 'aqura' ),
			'base' 		=> 'aqura_biography',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'First Column Content', 'aqura' ),
					'param_name' 	=> 'aqura_biography__first_content',
				),
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'Second Column Content', 'aqura' ),
					'param_name' 	=> 'aqura_biography__second_content',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Person', 'aqura' ),
					'param_name' 	=> 'aqura_biography__person',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Signature (Image)', 'aqura' ),
					'param_name' 	=> 'aqura_biography__signature',
				),
			)
		) );

	}

	public function aqura_featured_platform() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Featured Platform', 'aqura' ),
			'base' 		=> 'aqura_featured_platform',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_featured_platform__title',
					'std'			=> esc_html__( 'SoundClaoud' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Size - Title', 'aqura' ),
					'param_name' 	=> 'aqura_featured_platform__title__font_size',
					'description' 	=> esc_html__( 'You can use any units. E.g. "20px".' , 'aqura' ),
				),
				array(
					'type' 			=> 'colorpicker',
					'heading' 		=> esc_html__( 'Color - Title', 'aqura' ),
					'param_name' 	=> 'aqura_featured_platform__title_text_color',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background', 'aqura' ),
					'param_name' 	=> 'aqura_featured_platform__image',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'URL', 'aqura' ),
					'param_name' 	=> 'aqura_featured_platform__url',
				),
			)
		) );

	}

	public function aqura_about_me() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'About Me', 'aqura' ),
			'base' 		=> 'aqura_about_me',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_about_me__title',
				),
				array(
					'type' 			=> 'textarea',
					'heading' 		=> esc_html__( 'The Story', 'aqura' ),
					'param_name' 	=> 'aqura_about_me__story',
				),
				array(
					'type' 			=> 'attach_images',
					'heading' 		=> esc_html__( 'Images', 'aqura' ),
					'param_name' 	=> 'aqura_about_me__images',
					'description' 	=> esc_html( '3 Images Max' , 'aqura' ),
				),
			)
		) );

	}

	public function aqura_instagram_carousel() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Instagram Carousel', 'aqura' ),
			'base' 		=> 'aqura_instagram_carousel',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button Text', 'aqura' ),
					'param_name' 	=> 'aqura_instagram_carousel__title',
					'std'			=> esc_html__( 'Follow Us On Instagram' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Number of Photos Displayed', 'aqura' ),
					'param_name' 	=> 'aqura_instagram_carousel__number',
					'std'			=> '12',
				),
			)
		) );

	}

	public function aqura_instagram_carousel_small() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Instagram Carousel (Samll)', 'aqura' ),
			'base' 		=> 'aqura_instagram_carousel_small',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Number of Photos Displayed', 'aqura' ),
					'param_name' 	=> 'aqura_instagram_carousel_small__number',
					'std'			=> '12',
				),
			)
		) );

	}

	public function aqura_parallax_square_images() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Parallax Square Images', 'aqura' ),
			'base' 		=> 'aqura_parallax_square_images',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button Text', 'aqura' ),
					'param_name' 	=> 'aqura_parallax_square_images__button_text',
					'std'			=> esc_html__( 'Music Store' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button URL', 'aqura' ),
					'param_name' 	=> 'aqura_parallax_square_images__button_url',
					'std'			=> esc_html__( '#' , 'aqura' ),
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns', 'aqura' ),
					'param_name' 	=> 'aqura_parallax_square_images__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
						esc_html__( 'Six' , 'aqura' ) 	=> 'six',
					),
					'std'			=> 'four',
				),
				array(
					'type' 			=> 'attach_images',
					'heading' 		=> esc_html__( 'Images', 'aqura' ),
					'param_name' 	=> 'aqura_parallax_square_images__images',
				),
			)
		) );

	}

	public function aqura_glitch_square_images() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Glitch Square Images', 'aqura' ),
			'base' 		=> 'aqura_glitch_square_images',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params' 	=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button Text', 'aqura' ),
					'param_name' 	=> 'aqura_glitch_square_images__button_text',
					'std'			=> esc_html__( 'Music Store' , 'aqura' ),
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Button URL', 'aqura' ),
					'param_name' 	=> 'aqura_glitch_square_images__button_url',
					'std'			=> esc_html__( '#' , 'aqura' ),
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns', 'aqura' ),
					'param_name' 	=> 'aqura_glitch_square_images__cols',
					'value'			=> array(
						esc_html__( 'One' , 'aqura' ) 	=> 'one',
						esc_html__( 'Two' , 'aqura' ) 	=> 'two',
						esc_html__( 'Three' , 'aqura' ) => 'three',
						esc_html__( 'Four' , 'aqura' ) 	=> 'four',
						esc_html__( 'Six' , 'aqura' ) 	=> 'six',
					),
					'std'			=> 'four',
				),
				array(
					'type' 			=> 'attach_images',
					'heading' 		=> esc_html__( 'Images', 'aqura' ),
					'param_name' 	=> 'aqura_glitch_square_images__images',
				),
			)
		) );

	}

	public function aqura_scale_background() {
		
		vc_map( array(
			'name' 		=> esc_html__( 'Scale Background', 'aqura' ),
			'base' 		=> 'aqura_scale_background',
			'category' 	=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params'	=> array(
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'aqura' ),
					'param_name' 	=> 'aqura_scale_background__image',
				),
			)
		) );

	}

	public function aqura_stores_available() {
		
		vc_map( array(
			'name' 				=> esc_html__( 'Stores Available', 'aqura' ),
			'base' 				=> 'aqura_stores_available',
			'category' 			=> esc_html__( 'Aqura Shortcodes', 'aqura' ),
			'params'			=> array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'aqura' ),
					'param_name' 	=> 'aqura_stores_available__title',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Stores', 'aqura' ),
					'param_name' 	=> 'aqura_stores_available__image',
				),
			)
		) );

	}

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;

	}

}

VC_Setup::get_instance();

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Aqura_hero_buttons extends WPBakeryShortCodesContainer {}
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Aqura_hero_buttons__Button extends WPBakeryShortCode {}
}