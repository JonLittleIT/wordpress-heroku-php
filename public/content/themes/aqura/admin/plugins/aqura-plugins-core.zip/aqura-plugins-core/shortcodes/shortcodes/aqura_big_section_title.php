<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_big_section_title {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_big_section_title', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_big_section_title__title = $aqura_big_section_title__title__font_size = $aqura_big_section_title__title__color = $aqura_big_section_title__subtitle = $aqura_big_section_title__subtitle__font_size = $aqura_big_section_title__subtitle__color = $aqura_big_section_title__bg_title = $aqura_big_section_title__bg_title__font_size = $aqura_big_section_title__bg_title__color = '';

		extract( shortcode_atts( array(
			'aqura_big_section_title__title'				=> esc_html__( 'AQURA' , 'aqura' ),
			'aqura_big_section_title__title__font_size'		=> '',
			'aqura_big_section_title__title__color'			=> '',
			'aqura_big_section_title__subtitle'				=> esc_html__( 'Section' , 'aqura' ),
			'aqura_big_section_title__subtitle__font_size'	=> '',
			'aqura_big_section_title__subtitle__color'		=> '',
			'aqura_big_section_title__bg_title'				=> esc_html__( 'Secction Title' , 'aqura' ),
			'aqura_big_section_title__bg_title__font_size'	=> '',
			'aqura_big_section_title__bg_title__color'		=> '',
		), $atts ) );

		$aqura_big_section_title__title__first_word = strtok($aqura_big_section_title__title, ' ');
		$aqura_big_section_title__the_rest 	 		= str_replace($aqura_big_section_title__title__first_word, '', $aqura_big_section_title__title);

		$output .= '<div class="section-title-5">
						<div>
							<h1>
								<a style="font-size: ' . esc_attr( $aqura_big_section_title__bg_title__font_size ) . '; color: ' . esc_attr( $aqura_big_section_title__bg_title__color ) . ';">
									' . esc_html( $aqura_big_section_title__bg_title ) . '
								</a>
							</h1>
							<div class="sub-title">
								<h4>
									<a style="font-size: ' . esc_attr( $aqura_big_section_title__title__font_size ) . '; color: ' . esc_attr( $aqura_big_section_title__title__color ) . ';">
										<span>' . esc_html( $aqura_big_section_title__title__first_word ) . '</span>
										' . esc_html( $aqura_big_section_title__the_rest ) . '
									</a>
								</h4>
								<p style="font-size: ' . esc_attr( $aqura_big_section_title__subtitle__font_size ) . '; color: ' . esc_attr( $aqura_big_section_title__subtitle__color ) . ';">
									' . esc_html( $aqura_big_section_title__subtitle ) . '
								</p>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_big_section_title::get_instance();