<?php

// Register Custom Post Type
function aqura_albums() {

	$labels = array(
		'name'                  => _x( 'Albums', 'Post Type General Name', 'aqura' ),
		'singular_name'         => _x( 'Album', 'Post Type Singular Name', 'aqura' ),
		'menu_name'             => __( 'Albums', 'aqura' ),
		'name_admin_bar'        => __( 'Albums', 'aqura' ),
		'archives'              => __( 'Albums Archives', 'aqura' ),
		'parent_item_colon'     => __( 'Parent Album:', 'aqura' ),
		'all_items'             => __( 'All Albums', 'aqura' ),
		'add_new_item'          => __( 'Add New Album', 'aqura' ),
		'add_new'               => __( 'Add New', 'aqura' ),
		'new_item'              => __( 'New Album', 'aqura' ),
		'edit_item'             => __( 'Edit Album', 'aqura' ),
		'update_item'           => __( 'Update Album', 'aqura' ),
		'view_item'             => __( 'View Album', 'aqura' ),
		'search_items'          => __( 'Search Album', 'aqura' ),
		'not_found'             => __( 'Not found', 'aqura' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'aqura' ),
		'featured_image'        => __( 'Featured Image', 'aqura' ),
		'set_featured_image'    => __( 'Set featured image', 'aqura' ),
		'remove_featured_image' => __( 'Remove featured image', 'aqura' ),
		'use_featured_image'    => __( 'Use as featured image', 'aqura' ),
		'insert_into_item'      => __( 'Insert into item', 'aqura' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'aqura' ),
		'items_list'            => __( 'Albums list', 'aqura' ),
		'items_list_navigation' => __( 'Items list navigation', 'aqura' ),
		'filter_items_list'     => __( 'Filter items list', 'aqura' ),
	);
	$args = array(
		'label'                 => __( 'Album', 'aqura' ),
		'description'           => __( 'Aqura Albums', 'aqura' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'taxonomies'            => array( 'albums-category' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-album',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'albums', $args );

}
add_action( 'init', 'aqura_albums', 0 );

function aqura_albums_taxonomy() {
	register_taxonomy(
		'albums-category',
		'albums',
		array(
			'hierarchical' 		=> true,
			'label' 			=> __( 'Categories' , 'aqura' ) ,
			'query_var' 		=> true,
			'rewrite'			=> array(
				'slug' 			=> 'albums',
				'with_front' 	=> false
			)
		)
	);
}

add_action( 'init', 'aqura_albums_taxonomy');