<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_gallery_images {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_gallery_images', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_gallery_images__images = $aqura_gallery_images__gap = '';

		extract( shortcode_atts( array(
			'aqura_gallery_images__images'	=> '',
			'aqura_gallery_images__gap'		=> '0',
		), $atts ) );

		$aqura_gallery_images__images = explode(',', $aqura_gallery_images__images);

		$output .= '<div class="gallery-section-type-1 clearfix">';
					foreach( $aqura_gallery_images__images as $image_id ){
						$image = wp_get_attachment_url( $image_id );
			$output .= '<article class="gallery-item" style="padding: ' . esc_attr( $aqura_gallery_images__gap ) . ';">
							<figure>
								<a href="' . esc_url( $image ) . '" class="lightbox"><img src="' . esc_url( $image ) . '" alt="" /></a>
							</figure>
						</article>';
					}
		$output .= '</div>';

		return $output;
	}

}
Aqura_gallery_images::get_instance();