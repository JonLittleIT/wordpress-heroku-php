<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_hero_buttons {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_hero_buttons', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_hero_buttons__title = $aqura_hero_buttons__title__font_size = $aqura_hero_buttons__sup_title = $aqura_hero_buttons__low_title = $aqura_hero_buttons__bg_image = $aqura_hero_buttons__text_color = $aqura_hero_buttons__hide_stars = $aqura_hero_buttons__shadow = $aqura_hero_buttons__border_radius = $aqura_hero_buttons__stars = '';

		extract( shortcode_atts( array(
			'aqura_hero_buttons__title'				=> esc_html__( 'AQURA' , 'aqura' ),
			'aqura_hero_buttons__title__font_size'	=> '',
			'aqura_hero_buttons__sup_title'			=> esc_html__( 'THEME - BROTHER' , 'aqura' ),
			'aqura_hero_buttons__low_title'			=> esc_html__( 'WORDPRES' , 'aqura' ),
			'aqura_hero_buttons__bg_image'			=> '',
			'aqura_hero_buttons__text_color'		=> '',
			'aqura_hero_buttons__shadow' 			=> false,
			'aqura_hero_buttons__border_radius' 	=> false,
			'aqura_hero_buttons__stars' 			=> false
		), $atts ) );

		$aqura_hero_buttons__bg_image__url 	= wp_get_attachment_url( $aqura_hero_buttons__bg_image );

		$aqura_extra_classes = '';

		if ( $aqura_hero_buttons__shadow ) {
			$aqura_extra_classes .= ' section-shadow';
		}
		if ( $aqura_hero_buttons__border_radius ) {
			$aqura_extra_classes .= ' section-radius';
		}

		$output .= '<section class="no-mb">
						<div class="before-FullscreenSlider"></div>
						<div class="breadcrumb-fullscreen-parent phone-menu-bg affix-top ' . esc_attr( $aqura_extra_classes ) . '">
							<div class="breadcrumb breadcrumb-fullscreen alignleft small-description overlay almost-black-overlay" style="background-image: url(' . esc_url( $aqura_hero_buttons__bg_image__url ) . ');" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="0">';
								if ( $aqura_hero_buttons__stars ) {
					$output .= '<div id="home" style="position: absolute;left: 0;top: 0; width: 100%;">';
								} else {
					$output .= '<div id="home">';
								}
						$output .= '<div class="intro-header">
										<div class="js-height-full ';
										if ( $aqura_hero_buttons__stars ) {
								$output .= 'star">';
										} else {
								$output .= '">';
										}
								$output .= '<div class="star-pattern-1 js-height-full"></div>
											<div class="star-pattern-1 js-height-full"></div>
											<div class="hero-title-1 fade-element">
												<p style="color: ' . esc_attr( $aqura_hero_buttons__text_color ) . ';">' . esc_html( $aqura_hero_buttons__sup_title ) . '</p>
												<h1 style="font-size: ' . esc_attr( $aqura_hero_buttons__title__font_size ) . ';"><a style="color: ' . esc_attr( $aqura_hero_buttons__text_color ) . ';" class="link link-yaku">' . esc_html( $aqura_hero_buttons__title ) . '</a></h1>
												<p style="color: ' . esc_attr( $aqura_hero_buttons__text_color ) . ';">' . esc_html( $aqura_hero_buttons__low_title ) . '</p>
												<div class="hero-title-2-social">
													' . do_shortcode($content) . '
												</div>
											</div>';
											if ( $aqura_hero_buttons__stars ) {
								$output .= '<canvas class="cover"></canvas>';
											}
							$output .= '</div>
									</div>
								</div>
							</div>
						</div>
					</section>';

		return $output;
	}

}
Aqura_hero_buttons::get_instance();