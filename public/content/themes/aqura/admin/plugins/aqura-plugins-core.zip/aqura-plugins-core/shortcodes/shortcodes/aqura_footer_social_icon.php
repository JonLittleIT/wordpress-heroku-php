<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_footer_social_icon {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_footer_social_icon', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $icon = $href = $target = '';

		extract( shortcode_atts( array(
			'icon'         => 'fa-facebook',
			'href'         => '#',
			'target'       => '_blank',
		), $atts ) );

		$output .= '<li>
						<a href="' . esc_url( $href ) . '" target="' . esc_attr( $target ) . '">
							<i class="fa ' . esc_attr( $icon ) . '" aria-hidden="true"></i>
							<span></span>
						</a>
					</li>';

		return $output;
	}

}
Aqura_footer_social_icon::get_instance();