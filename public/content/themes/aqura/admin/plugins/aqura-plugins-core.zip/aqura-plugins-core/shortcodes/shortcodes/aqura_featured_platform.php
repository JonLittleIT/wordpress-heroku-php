<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_featured_platform {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_featured_platform', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_featured_platform__title = $aqura_featured_platform__title__font_size = $aqura_featured_platform__title_text_color = $aqura_featured_platform__image = '';

		extract( shortcode_atts( array(
			'aqura_featured_platform__title'				=> esc_html__( 'SoundClaoud' , 'aqura' ),
			'aqura_featured_platform__title__font_size'		=> '',
			'aqura_featured_platform__title_text_color'		=> '',
			'aqura_featured_platform__image'				=> '',
			'aqura_featured_platform__url'					=> '',
		), $atts ) );

		$aqura_featured_platform__image = wp_get_attachment_url( $aqura_featured_platform__image , 'full' );

		$output .= '<div class="simple-block">
						<div class="block-container">
							<div class="block">
								<a href="' . esc_url( $aqura_featured_platform__url ) . '"><img src="' . esc_url( $aqura_featured_platform__image ) . '" alt=""></a>
							</div>
							<div class="block-container-hover">
								<a href="' . esc_url( $aqura_featured_platform__url ) . '" style="font-size: ' . esc_attr( $aqura_featured_platform__title__font_size ) . '; color: ' . esc_attr( $aqura_featured_platform__title_text_color ) . ';">' . esc_html( $aqura_featured_platform__title ) . '</a>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_featured_platform::get_instance();