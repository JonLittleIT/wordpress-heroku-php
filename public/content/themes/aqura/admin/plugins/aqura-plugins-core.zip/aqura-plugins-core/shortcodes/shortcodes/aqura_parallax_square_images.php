<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_parallax_square_images {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_parallax_square_images', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_parallax_square_images__button_text = $aqura_parallax_square_images__button_url = $aqura_parallax_square_images__images = $aqura_parallax_square_images__cols = '';

		extract( shortcode_atts( array(
			'aqura_parallax_square_images__button_text'	=> esc_html__( 'Music Store' , 'aqura' ),
			'aqura_parallax_square_images__button_url'	=> esc_html__( '#' , 'aqura' ),
			'aqura_parallax_square_images__images'		=> '',
			'aqura_parallax_square_images__cols'		=> 'four',
		), $atts ) );

		$aqura_parallax_square_images__images = explode(',', $aqura_parallax_square_images__images);

		$aqura_cols = 'col-sm-3';

		if ( $aqura_parallax_square_images__cols == 'one' ) {
			$aqura_cols = 'col-sm-12';
		} else if ( $aqura_parallax_square_images__cols == 'two' ) {
			$aqura_cols = 'col-sm-6';
		} else if ( $aqura_parallax_square_images__cols == 'three' ) {
			$aqura_cols = 'col-sm-4';
		} else if ( $aqura_parallax_square_images__cols == 'six' ) {
			$aqura_cols = 'col-sm-2';
		}

		$output .= '<div class="albums-parallax">
						<div class="row">
							<div class="cherry-button">
								<a href="' . esc_url( $aqura_parallax_square_images__button_url ) . '">
									' . esc_html( $aqura_parallax_square_images__button_text ) . '
								</a>
							</div>
							<div class="parallax-covers">';
							foreach( $aqura_parallax_square_images__images as $image_id ) {
								$image = wp_get_attachment_url( $image_id );
					$output .= '<div class="' . esc_attr( $aqura_cols ) . '">
									<div class="albums-parallax-content">
										<div class="parallax-container custom-parallax">
											<div class="parallax">
												<img src="' . esc_url( $image ) . '" alt="">
											</div>
										</div>
									</div>
								</div>';
							}
				$output .= '</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_parallax_square_images::get_instance();