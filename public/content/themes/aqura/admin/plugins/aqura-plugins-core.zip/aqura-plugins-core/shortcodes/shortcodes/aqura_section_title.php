<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_section_title {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_section_title', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_section_title__title = $aqura_section_title__title__font_size = $aqura_section_title__title__color = $aqura_section_title__space = $aqura_section_title__underline_show_hide = $aqura_section_title__underline_color = $aqura_section_title__underline_content = $aqura_section_title__underline_width = $aqura_section_title__underline_height = $aqura_section_title__margin_bottom = '';

		extract( shortcode_atts( array(
			'aqura_section_title__title'				=> esc_html__( 'AQURA' , 'aqura' ),
			'aqura_section_title__title__font_size'		=> '',
			'aqura_section_title__title__color'			=> '',
			'aqura_section_title__space'				=> '',
			'aqura_section_title__underline_hide'		=> '',
			'aqura_section_title__underline_color'		=> '',
			'aqura_section_title__underline_content'	=> '',
			'aqura_section_title__underline_width'		=> '',
			'aqura_section_title__underline_height'		=> '',
			'aqura_section_title__margin_bottom'		=> '',
		), $atts ) );

		$aqura_title_style 		= '';
		$aqura_underline_style 	= '';
		$aqura_underline_class	= 'underline-1';
		$aqura_title_class		= 'section-title-1';

		if ( $aqura_section_title__title__font_size != '' ) {
			$aqura_title_style .= 'font-size:' . $aqura_section_title__title__font_size . ';';
		}
		if ( $aqura_section_title__title__color != '' ) {
			$aqura_title_style .= 'color:' . $aqura_section_title__title__color . ';';
		}

		if ( $aqura_section_title__space != '' ) {
			$aqura_underline_style .= 'margin-top:' . $aqura_section_title__space . ';';
		}

		if ( $aqura_section_title__underline_content === '' ) {
			if ( $aqura_section_title__underline_color != '' ) {
				$aqura_underline_style .= 'background-color:' . $aqura_section_title__underline_color . ';';
			}
			if ( $aqura_section_title__underline_width != '' ) {
				$aqura_underline_style .= 'width:' . $aqura_section_title__underline_width . ';';
			}
			if ( $aqura_section_title__underline_height != '' ) {
				$aqura_underline_style .= 'height:' . $aqura_section_title__underline_height . ';';
			}
		} else {
			if ( $aqura_section_title__underline_color != '' ) {
				$aqura_underline_style .= 'color:' . $aqura_section_title__underline_color . ';';
			}
			$aqura_underline_class	= 'underline-2';
			$aqura_title_class		= 'section-title-2';
		}

		$output .= '<div class="' . esc_attr( $aqura_title_class ) . '" style="margin-bottom:' . esc_attr( $aqura_section_title__margin_bottom ) . ';">
						<h1>
							<a style="' . esc_attr( $aqura_title_style ) . '">
								' . esc_html( $aqura_section_title__title ) . '
							</a>
						</h1>';
						if ( $aqura_section_title__underline_hide == false ) {
			$output .= '<span class="' . esc_attr( $aqura_underline_class ) . '" style="' . esc_attr( $aqura_underline_style ) . '">
							' . esc_html( $aqura_section_title__underline_content ) . '
						</span>';
						}
			$output .= '</div>';

		return $output;
	}

}
Aqura_section_title::get_instance();