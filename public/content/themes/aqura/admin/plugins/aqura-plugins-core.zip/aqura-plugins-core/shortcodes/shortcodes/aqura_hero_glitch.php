<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_hero_glitch {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_hero_glitch', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_hero_glitch__image = $aqura_hero_glitch__shadow = $aqura_hero_glitch__radius = '';

		extract( shortcode_atts( array(
			'aqura_hero_glitch__image'	=> '',
			'aqura_hero_glitch__shadow'	=> '',
			'aqura_hero_glitch__radius'	=> '',
		), $atts ) );

		$aqura_hero_glitch__image__url = wp_get_attachment_url( $aqura_hero_glitch__image );

		$aqura_glitch_classes = '';

		if ( $aqura_hero_glitch__radius ) {
			$aqura_glitch_classes .= 'section-radius';
		}

		if ( $aqura_hero_glitch__shadow ) {
			$aqura_glitch_classes .= 'section-radius';
		}

		$output .= '<div class="glitch-hero ' . esc_attr( $aqura_glitch_classes ) . '">
						<div class="glitch">
							<div class="glitch__img" style="background-image: url( ' . esc_url( $aqura_hero_glitch__image__url ) . ' );"></div>
							<div class="glitch__img" style="background-image: url( ' . esc_url( $aqura_hero_glitch__image__url ) . ' );"></div>
							<div class="glitch__img" style="background-image: url( ' . esc_url( $aqura_hero_glitch__image__url ) . ' );"></div>
							<div class="glitch__img" style="background-image: url( ' . esc_url( $aqura_hero_glitch__image__url ) . ' );"></div>
							<div class="glitch__img" style="background-image: url( ' . esc_url( $aqura_hero_glitch__image__url ) . ' );"></div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_hero_glitch::get_instance();