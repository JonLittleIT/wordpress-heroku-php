<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_header_image {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_header_image', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_header_image__title = $aqura_header_image__title__font_size = $aqura_header_image__description = $aqura_header_image__description__font_size = $aqura_header_image__view_more = $aqura_header_image__view_more__font_size = $aqura_header_image__bg = $aqura_header_image__color = $aqura_header_image__alignment = '';

		extract( shortcode_atts( array(
			'aqura_header_image__title'						=> '',
			'aqura_header_image__title__font_size'			=> '',
			'aqura_header_image__description'				=> '',
			'aqura_header_image__description__font_size'	=> '',
			'aqura_header_image__view_more'					=> '',
			'aqura_header_image__view_more__font_size'		=> '',
			'aqura_header_image__bg'						=> '',
			'aqura_header_image__color'						=> '',
		), $atts ) );

		global $aqura_data;

		if ( $aqura_header_image__title != '' ) {} elseif ( get_the_title() != '' ) {
			$aqura_header_image__title = get_the_title();
		} else {
			$aqura_header_image__title = $aqura_data['aqura_header__header_image__title'];
		}

		if ( $aqura_header_image__description != '' ) {} else {
			$aqura_header_image__description = $aqura_data['aqura_header__header_image__text'];
		}

		if ( $aqura_header_image__view_more != '' ) {} else {
			$aqura_header_image__view_more = $aqura_data['aqura_header__header_image__view_more_text'];
		}

		if ( $aqura_header_image__bg != '' ) {
			$aqura_header_image__bg = wp_get_attachment_url( $aqura_header_image__bg );
		} else {
			$aqura_header_image__bg = $aqura_data['aqura_header__header_image__image']['url'];
		}

		$aqura_title_style 			= '';
		$aqura_description_style 	= '';
		$aqura_view_more_style 		= '';

		if ( $aqura_header_image__title__font_size != '' ) {
			$aqura_title_style .= 'font-size:' . $aqura_header_image__title__font_size . ';';
		}
		if ( $aqura_header_image__description__font_size != '' ) {
			$aqura_description_style .= 'font-size:' . $aqura_header_image__description__font_size . ';';
		}
		if ( $aqura_header_image__view_more__font_size != '' ) {
			$aqura_view_more_style .= 'font-size:' . $aqura_header_image__view_more__font_size . ';';
		}

		if ( $aqura_header_image__color != '' ) {
			$aqura_title_style 			.= 'color:' . $aqura_header_image__color . ';';
			$aqura_description_style 	.= 'color:' . $aqura_header_image__color . ';';
			$aqura_view_more_style 		.= 'color:' . $aqura_header_image__color . ';';
		}

		$output .= '<section class="no-mb">
						<div class="before-FullscreenSlider"></div>
						<div class="breadcrumb-fullscreen-parent phone-menu-bg affix-top">
							<div class="breadcrumb breadcrumb-fullscreen alignleft small-description overlay almost-black-overlay" style="background-image: url(' . esc_url( $aqura_header_image__bg ) . ');" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="0">
								<div class="hero-content-type-1 fade-element">
									<h1 style="' . esc_attr( $aqura_title_style ) . '">' . esc_html( $aqura_header_image__title ) . '</h1>
									<p style="' . esc_attr( $aqura_description_style ) . '">' . $aqura_header_image__description . '</p>
									<a style="' . esc_attr( $aqura_view_more_style ) . '" href="#view-more-scroll" data-easing="easeInOutQuint" data-scroll="" data-speed="900" data-url="false" class="view-more-type-1">' . esc_html( $aqura_header_image__view_more ) . '<i class="fa fa-angle-down" style="color: ' . esc_attr( $aqura_header_image__color ) . ';"></i></a>
								</div>
							</div>
						</div>
					</section>
					<div id="view-more-scroll"></div>';

		return $output;
	}

}
Aqura_header_image::get_instance();