<?php
/**
 * @author Stylish Themes
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class AQURA_bandsintown {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_bandsintown', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts ){

		$output = $aqura_bandsintown__artist = $aqura_bandsintown__number = '';

		extract( shortcode_atts( array(
			'aqura_bandsintown__artist'	=> '',
			'aqura_bandsintown__number'	=> '5',
		), $atts ) );

		$output .= sprintf('<script charset="utf-8" src="https://widget.bandsintown.com/main.min.js"></script><a href="http://www.bandsintown.com" class="bit-widget-initializer" data-share-links="false" data-display-past-dates="true" data-display-limit="%2$s" data-artist-name="%1$s">%3$s</a>', $aqura_bandsintown__artist, $aqura_bandsintown__number, esc_html__('Bandsintown', 'aqura'));

		return $output;

	}

}

AQURA_bandsintown::get_instance();