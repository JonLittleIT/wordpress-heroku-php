<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_instagram_carousel {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_instagram_carousel', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_instagram_carousel__title = $aqura_instagram_carousel__number = '';

		extract( shortcode_atts( array(
			'aqura_instagram_carousel__title' 	=> esc_html__( 'Follow Us On Instagram' , 'aqura' ),
			'aqura_instagram_carousel__number'	=> '12',
		), $atts ) );

		global $aqura_data;

		$aqura_json = wp_remote_get("https://api.instagram.com/v1/users/self/?access_token={$aqura_data['aqura_theme__api__instagram']}");
		if ( strpos($aqura_json['body'], '"id"') !== false ) {
			$aqura_data_json = json_decode($aqura_json['body']);

			$user_id = $aqura_data_json->data->id;

			$aqura_json = wp_remote_get("https://api.instagram.com/v1/users/{$aqura_data['aqura_theme__api__instagram_user']}/media/recent/?count={$aqura_instagram_carousel__number}&access_token={$aqura_data['aqura_theme__api__instagram']}");
			$aqura_data_json = json_decode($aqura_json['body']);

			$aqura_images = array();
			foreach( $aqura_data_json->data as $user_data ) {
				$aqura_images[] = (array) $user_data->images;
				$aqura_links[] = (array) $user_data->link;
			}

			$aqura_standard = array_map( function( $item ) {
				return $item['standard_resolution']->url;
			}, $aqura_images );

			$i = 0;
$output .= '<div class="progress-instagram">
				<div class="insta-button">
					<a href="#"><i class="fa fa-instagram"></i>' . esc_html( $aqura_instagram_carousel__title ) . '</a>
				</div>
				<div class="insta-carousel-type-3">';
			foreach( $aqura_standard as $img_url ) {

		$output .= '<div class="item">
						<a href="' . esc_url( $img_url ) . '" class="fluidbox">
							<img src="' . esc_url( $img_url ) . '" alt="' . esc_html__( 'instagram' , 'aqura' ) . '">
						</a>
					</div>';

				$i++;

			}
	$output .= '</div>
			</div>';

		}

		return $output;
	}

}
Aqura_instagram_carousel::get_instance();