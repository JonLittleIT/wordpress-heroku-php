<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_contact_form {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_contact_form', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_contact_form__title = $aqura_contact_form__title__font_size = $aqura_contact_form__shortcode = '';

		extract( shortcode_atts( array(
			'aqura_contact_form__title'					=> esc_html__( 'CONTACT INFORMATION' , 'aqura' ),
			'aqura_contact_form__title__font_size' 		=> '',
			'aqura_contact_form__shortcode' 			=> '',
		), $atts ) );

		add_filter( 'wpcf7_form_class_attr', 'custom_custom_form_class_attr' );
		function custom_custom_form_class_attr( $class ) {
			$class .= ' comment-form';
			return $class;
		}

		$output .= '<div class="contact-type-1">
						<div class="contact-type-1-form">
							<h4 style="font-size: ' . esc_attr( $aqura_contact_form__title__font_size ) . ';">' . esc_html( $aqura_contact_form__title ) . '</h4>
							<div class="form-type-1">
							    <div class="comment-respond">
							        ' . do_shortcode( '[contact-form-7 id="' . esc_html( $aqura_contact_form__shortcode ) . '"]' ) . '
							    </div>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_contact_form::get_instance();