<?php

// File Security Check

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Creating the widget 

class WP_popular_articles extends WP_Widget {

	protected $defaults;

	function __construct() {

		$this->defaults = array(
            'title'  => esc_html__( 'Popular Articles' , 'aqura' ),
            'articles_number' => 4,
        );

		parent::__construct(

			// Base ID of your widget
			'WP_popular_articles', 

			// Widget name will appear in UI
			esc_html__('Popular Articles', 'aqura')

		);

	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $aqura_args, $instance ) {

		echo balanceTags($aqura_args['before_widget']);

		$aqura_title = apply_filters( 'widget_title', $instance['title'] );
		$aqura_articles_number = $instance['articles_number'] ? $instance['articles_number'] : $this->defaults['articles_number'];

		if ( ! empty( $aqura_title ) )
			echo balanceTags($aqura_args['before_title']) . esc_html($aqura_title) . balanceTags($aqura_args['after_title']);

		$aqura_popular_articles_args = array(
	        'posts_per_page' => $aqura_articles_number,
	        'post_status'    => 'published',
	        'orderby'        => 'meta_value_num',
	        'meta_key'       => 'views',
	        'order'          => 'DESC',
	    );
	    $aqura_popular_articles = new WP_Query( $aqura_popular_articles_args );
	    if ( $aqura_popular_articles->have_posts() ) {
	        while ( $aqura_popular_articles->have_posts() ) {
	            $aqura_popular_articles->the_post();
	            echo get_the_title();

	            echo '<div class="widget-post">
						<article>
							<figure>
								<a href="' . get_the_permalink() . '">';
									the_post_thumbnail();
						echo   '</a>
							</figure>
							<div class="content-post">
								<header>
									<a href="' . get_the_permalink() . '">
										<h6>
											' . get_the_title() . '
										</h6>
									</a>
								</header>
								<footer class="post-meta-widget">
									<span><i class="fa fa-eye" aria-hidden="true"></i></span>
									<span>' . get_post_meta(get_the_ID(), "views")[0] . '</span>
									<span class="separator"></span>
									<a href="' . get_the_permalink() . '">
										<span><i class="fa fa-comment-o" aria-hidden="true"></i></span>
										<span class="comm-count">
											' . get_comments_number(get_the_ID()) . '
										</span>
									</a>
								</footer>
							</div>
						</article>
					</div>';

	        }
	    }

	    wp_reset_query();

		echo balanceTags($aqura_args['after_widget']);

	}


	// Widget Backend 
	public function form( $instance ) {

		if ( isset( $instance[ 'title' ] ) ) {
			$aqura_title = $instance[ 'title' ];
		} else {
			$aqura_title = $this->defaults['title'];
		};

		if ( isset( $instance[ 'articles_number' ] ) ) {
			$aqura_articles_number = $instance[ 'articles_number' ];
		} else {
			$aqura_articles_number = $this->defaults['articles_number'];
		}; ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">
					<?php esc_html_e( 'Title:' , 'aqura' ); ?>
			</label> 
			<input class="widefat"
				id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" 
				name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" 
				value="<?php echo esc_attr( $aqura_title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">
					<?php esc_html_e( 'Title:' , 'aqura' ); ?>
			</label> 
			<input class="widefat"
				type="number"
				id="<?php echo esc_attr($this->get_field_id( 'articles_number' )); ?>" 
				name="<?php echo esc_attr($this->get_field_name( 'articles_number' )); ?>" type="text" 
				value="<?php echo esc_attr( $aqura_articles_number ); ?>" />
		</p>
<?php }

	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : $this->defaults['title'];
		$instance['articles_number'] = ( ! empty( $new_instance['articles_number'] ) ) ? strip_tags( $new_instance['articles_number'] ) : $this->defaults['articles_number'];
		return $instance;
	}

} // Class WP_popular_articles ends here
