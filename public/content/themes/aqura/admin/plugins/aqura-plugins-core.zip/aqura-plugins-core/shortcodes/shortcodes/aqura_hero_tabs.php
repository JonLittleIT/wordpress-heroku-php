<?php
/**
 * @author Stylish Themes
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class AQURA_hero_tabs {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_hero_tabs', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts ){
		$output = $aqura_hero_tabs__first_member_name = $aqura_hero_tabs__first_member_profession = $aqura_hero_tabs__first_member_anchor = $aqura_hero_tabs__first_member_image = $aqura_hero_tabs__second_member_name = $aqura_hero_tabs__second_member_profession = $aqura_hero_tabs__second_member_anchor = $aqura_hero_tabs__second_member_image = $aqura_hero_tabs__third_member_name = $aqura_hero_tabs__third_member_profession = $aqura_hero_tabs__third_member_anchor = $aqura_hero_tabs__third_member_image = $aqura_hero_tabs__fourth_member_name = $aqura_hero_tabs__fourth_member_profession = $aqura_hero_tabs__fourth_member_anchor = $aqura_hero_tabs__fourth_member_image = $aqura_hero_tabs__fifth_member_name = $aqura_hero_tabs__fifth_member_profession = $aqura_hero_tabs__fifth_member_anchor = $aqura_hero_tabs__fifth_member_image = $aqura_hero_tabs__aqura_hero_tabs_image = '';

		extract( shortcode_atts( array(
			'aqura_hero_tabs__first_member_name' 					=> '',
			'aqura_hero_tabs__first_member_profession' 				=> '',
			'aqura_hero_tabs__first_member_anchor' 					=> '#',
			'aqura_hero_tabs__first_member_image' 					=> '',

			'aqura_hero_tabs__second_member_name' 					=> '',
			'aqura_hero_tabs__second_member_profession' 			=> '',
			'aqura_hero_tabs__second_member_anchor' 				=> '#',
			'aqura_hero_tabs__second_member_image' 					=> '',

			'aqura_hero_tabs__third_member_name' 					=> '',
			'aqura_hero_tabs__third_member_profession' 				=> '',
			'aqura_hero_tabs__third_member_anchor' 					=> '#',
			'aqura_hero_tabs__third_member_image' 					=> '',

			'aqura_hero_tabs__fourth_member_name' 					=> '',
			'aqura_hero_tabs__fourth_member_profession' 			=> '',
			'aqura_hero_tabs__fourth_member_anchor' 				=> '#',
			'aqura_hero_tabs__fourth_member_image' 					=> '',

			'aqura_hero_tabs__fifth_member_name' 					=> '',
			'aqura_hero_tabs__fifth_member_profession' 				=> '',
			'aqura_hero_tabs__fifth_member_anchor' 					=> '#',
			'aqura_hero_tabs__fifth_member_image' 					=> '',

			'aqura_hero_tabs__aqura_hero_tabs_image' 				=> ''
		), $atts ) );

		$aqura_hero_tabs__aqura_hero_tabs_image_src = wp_get_attachment_image_src($aqura_hero_tabs__aqura_hero_tabs_image, "full");
		$first_member_img 	= wp_get_attachment_image_src($aqura_hero_tabs__first_member_image, "full");
		$second_member_img 	= wp_get_attachment_image_src($aqura_hero_tabs__second_member_image, "full");
		$third_member_img 	= wp_get_attachment_image_src($aqura_hero_tabs__third_member_image, "full");
		$fourth_member_img 	= wp_get_attachment_image_src($aqura_hero_tabs__fourth_member_image, "full");
		$fifth_member_img 	= wp_get_attachment_image_src($aqura_hero_tabs__fifth_member_image, "full");

$output .= '<section class="no-mb">
				<div class="<div class="before-FullscreenSlider"></div>
				<div class="breadcrumb-fullscreen-parent phone-menu-bg affix-top">
					<div class="breadcrumb band-bgk breadcrumb-fullscreen alignleft small-description overlay almost-black-overlay" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="0" data-image-src="' . $aqura_hero_tabs__aqura_hero_tabs_image_src[0] . '" >
						<div class="container fade-element">
							<div class="band-members" style="max-width: inherit;">
								<ul>';
								if ( $aqura_hero_tabs__first_member_name != '' || $aqura_hero_tabs__first_member_profession != '' || $aqura_hero_tabs__first_member_anchor != '#' || $aqura_hero_tabs__first_member_image != '' ) {
						$output .= '<li data-image-src="' . $first_member_img[0] . '">
										<span class="band-member-info">
											<h4>' . $aqura_hero_tabs__first_member_name . '</h4>
											<h5>' . $aqura_hero_tabs__first_member_profession . '</h5>
										</span>

										<span class="readMore">
											<a href="' . $aqura_hero_tabs__first_member_anchor . '">' . esc_html__( 'Read More' , 'aqura' ) . '</a>
										</span>
									</li>';
								}
								if ( $aqura_hero_tabs__second_member_name != '' || $aqura_hero_tabs__second_member_profession != '' || $aqura_hero_tabs__second_member_anchor != '#' || $aqura_hero_tabs__second_member_image != '' ) {
						$output .= '<li data-image-src="' . $second_member_img[0] . '">
										<span class="band-member-info">
											<h4>' . $aqura_hero_tabs__second_member_name . '</h4>
											<h5>' . $aqura_hero_tabs__second_member_profession . '</h5>
										</span>

										<span class="readMore">
											<a href="' . $aqura_hero_tabs__second_member_anchor . '">' . esc_html__( 'Read More' , 'aqura' ) . '</a>
										</span>
									</li>';
								}
								if ( $aqura_hero_tabs__third_member_name != '' || $aqura_hero_tabs__third_member_profession != '' || $aqura_hero_tabs__third_member_anchor != '#' || $aqura_hero_tabs__third_member_image != '' ) {
						$output .= '<li data-image-src="' . $third_member_img[0] . '">
										<span class="band-member-info">
											<h4>' . $aqura_hero_tabs__third_member_name . '</h4>
											<h5>' . $aqura_hero_tabs__third_member_profession . '</h5>
										</span>

										<span class="readMore">
											<a href="' . $aqura_hero_tabs__third_member_anchor . '">' . esc_html__( 'Read More' , 'aqura' ) . '</a>
										</span>
									</li>';
								}
								if ( $aqura_hero_tabs__fourth_member_name != '' || $aqura_hero_tabs__fourth_member_profession != '' || $aqura_hero_tabs__fourth_member_anchor != '#' || $aqura_hero_tabs__fourth_member_image != '' ) {
						$output .= '<li data-image-src="' . $fourth_member_img[0] . '">
										<span class="band-member-info">
											<h4>' . $aqura_hero_tabs__fourth_member_name . '</h4>
											<h5>' . $aqura_hero_tabs__fourth_member_profession . '</h5>
										</span>

										<span class="readMore">
											<a href="' . $aqura_hero_tabs__fourth_member_anchor . '">' . esc_html__( 'Read More' , 'aqura' ) . '</a>
										</span>
									</li>';
								}
								if ( $aqura_hero_tabs__fifth_member_name != '' || $aqura_hero_tabs__fifth_member_profession != '' || $aqura_hero_tabs__fifth_member_anchor != '#' || $aqura_hero_tabs__fifth_member_image != '' ) {
						$output .= '<li data-image-src="' . $fifth_member_img[0] . '">
										<span class="band-member-info">
											<h4>' . $aqura_hero_tabs__fifth_member_name . '</h4>
											<h5>' . $aqura_hero_tabs__fifth_member_profession . '</h5>
										</span>

										<span class="readMore">
											<a href="' . $aqura_hero_tabs__fifth_member_anchor . '">' . esc_html__( 'Read More' , 'aqura' ) . '</a>
										</span>
									</li>';
								}
					$output .= '</ul>
							</div>
						</div>
					</div>
				</div>
			</section>';

		return $output;
	}

}

AQURA_hero_tabs::get_instance();