<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_glitch_square_images {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_glitch_square_images', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_glitch_square_images__button_text = $aqura_glitch_square_images__button_url = $aqura_glitch_square_images__images = $aqura_glitch_square_images__cols = '';

		extract( shortcode_atts( array(
			'aqura_glitch_square_images__button_text'	=> esc_html__( 'Music Store' , 'aqura' ),
			'aqura_glitch_square_images__button_url'	=> esc_html__( '#' , 'aqura' ),
			'aqura_glitch_square_images__images'		=> '',
			'aqura_glitch_square_images__cols'			=> 'four',
		), $atts ) );

		$aqura_glitch_square_images__images = explode(',', $aqura_glitch_square_images__images);

		$aqura_cols = 'col-sm-3';

		if ( $aqura_glitch_square_images__cols == 'one' ) {
			$aqura_cols = 'col-sm-12';
		} else if ( $aqura_glitch_square_images__cols == 'two' ) {
			$aqura_cols = 'col-sm-6';
		} else if ( $aqura_glitch_square_images__cols == 'three' ) {
			$aqura_cols = 'col-sm-4';
		} else if ( $aqura_glitch_square_images__cols == 'six' ) {
			$aqura_cols = 'col-sm-2';
		}

		$output .= '<div class="crew-block margin-bottom">
						<div class="row">
							<div class="glitch-hover">';
							foreach( $aqura_glitch_square_images__images as $image_id ) {
								$image = wp_get_attachment_url( $image_id );
					$output .= '<div class="' . esc_attr( $aqura_cols ) . '">
									<div class="grid__item">
										<div class="glitch glitch--vertical glitch-img-one glitch--style-">
											<div class="glitch__img" style="background-image: url( ' . esc_url( $image ) . ' );"></div>
											<div class="glitch__img" style="background-image: url( ' . esc_url( $image ) . ' );"></div>
											<div class="glitch__img" style="background-image: url( ' . esc_url( $image ) . ' );"></div>
											<div class="glitch__img" style="background-image: url( ' . esc_url( $image ) . ' );"></div>
											<div class="glitch__img" style="background-image: url( ' . esc_url( $image ) . ' );"></div>
										</div>
									</div>
								</div>';
							}
				$output .= '</div>
							<div class="cherry-button light-button">
								<a href="' . esc_url( $aqura_glitch_square_images__button_url ) . '">
									' . esc_html( $aqura_glitch_square_images__button_text ) . '
								</a>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_glitch_square_images::get_instance();