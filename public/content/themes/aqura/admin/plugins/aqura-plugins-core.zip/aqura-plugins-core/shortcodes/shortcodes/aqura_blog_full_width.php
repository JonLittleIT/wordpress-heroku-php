<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_blog_full_width {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_blog_full_width', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_blog_full_width__number = $aqura_blog_full_width__title__font_size = '';

		extract( shortcode_atts( array(
			'aqura_blog_full_width__number' 			=> '3',
			'aqura_blog_full_width__title__font_size' 	=> '',
		), $atts ) );

		global $wp_query;

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
		else { $paged = 1; }

		$args = array(
			'post_status'		=> 'publish',
			'orderby' 			=> 'date',
			'order' 			=> 'DESC',
			'paged'				=> $paged,
			'posts_per_page'	=> $aqura_blog_full_width__number,
		);

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$output .= '<div class="blog-list-type-1">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();

				$aqura_the_permalink = get_the_permalink();

				$aqura_post__options__article_type__the_type 			= rwmb_meta( 'aqura_post__options__article_type__the_type' );
				$aqura_post__options__article_type__soundcloud_track_id = rwmb_meta( 'aqura_post__options__article_type__soundcloud_track_id' );
				$aqura_post__options__article_type__video_id 			= rwmb_meta( 'aqura_post__options__article_type__video_id' );
				$aqura_post__options__article_type__quote_text 			= rwmb_meta( 'aqura_post__options__article_type__quote_text' );
				$aqura_post__options__article_type__quote_icon 			= rwmb_meta( 'aqura_post__options__article_type__quote_icon' );
				$aqura_post__options__article_type__quote_author 		= rwmb_meta( 'aqura_post__options__article_type__quote_author' );
				$aqura_post__options__article_type__gallery_images 		= rwmb_meta( 'aqura_post__options__article_type__gallery_images' , array( 'size' => 'thumbnail' ) );

				$output .= '<article class="col-sm-12">
								<figure class="list-figure col-sm-4">';
									if ( $aqura_post__options__article_type__the_type === "standard" ):

								$output .= '<a href="' . esc_url( $aqura_the_permalink ) . '" class="image">
												' . get_the_post_thumbnail(get_the_ID(), 'full') . '
											</a>';

									elseif ( $aqura_post__options__article_type__the_type === "soundcloud" ):
										if ( $aqura_post__options__article_type__soundcloud_track_id != "" ):

								$output .= '<iframe class="single-article-top-format-iframe" width="100" height="53"  src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . esc_attr($aqura_post__options__article_type__soundcloud_track_id) . '&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "youtube" ) :
										if ( $aqura_post__options__article_type__video_id != "" ):

								$output .= '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . esc_attr($aqura_post__options__article_type__video_id) . '" allowfullscreen></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "vimeo" ) :
										if ( $aqura_post__options__article_type__video_id != "" ):

								$output .= '<iframe src="https://player.vimeo.com/video/' . esc_attr($aqura_post__options__article_type__video_id) . '?title=0&byline=0&portrait=0" allowfullscreen></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "quote" ) :
										if ( $aqura_post__options__article_type__quote_text !== "" ):

								$output .= '<div class="blog-single-type-2">
												<div class="grid-item">
													<div class="featured-area" style="background: none;">
														<div class="title">
															<h3><a>“' . esc_html( $aqura_post__options__article_type__quote_text ) . '”</a></h3>';
															if ( $aqura_post__options__article_type__quote_icon !== "" ):

													$output .= '<i class="fa ' . esc_attr( $aqura_post__options__article_type__quote_icon ) . '" aria-hidden="true"></i>';

															endif;
															if ( $aqura_post__options__article_type__quote_author !== "" ):

													$output .= '<a class="author">—' . esc_html(  $aqura_post__options__article_type__quote_author ) . '</a>';

															endif;
											$output .= '</div>
													</div>
												</div>
											</div>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "gallery" ) :
										if ( $aqura_post__options__article_type__gallery_images !== "" ):

								$output .= '<div class="owl-carousel custom-arrow-carousel">';
										foreach ( $aqura_post__options__article_type__gallery_images as $image ) {
									$output .= '<div class="item"><img src="' . esc_url( $image["full_url"] ) . '" alt="' . esc_attr( $image["alt"] ) . '"></div>';
										}
								$output .= '</div>';

										endif;
									endif;
					$output .= '</figure>
								<div class="box col-sm-8">
									<header>
										<div class="title">
											<h4><a href="' . esc_url( $aqura_the_permalink ) . '" style="font-size:' . esc_attr( $aqura_blog_full_width__title__font_size ) . ';">' . get_the_title() . '</a></h4>
										</div>
										<aside class="post-meta">
											<p>' . get_the_date() . ' ' . aqura_get_posted_by() . '</p>
										</aside>
									</header>
									<div class="article-content">
										<p>' . esc_html(mb_strimwidth(get_the_content(), 0, 200, '...')) . '</p>
									</div>
									<footer>
										<a href="' . esc_url( $aqura_the_permalink ) . '" class="read-more">
											' . esc_html__( "Read More" , "aqura" ) . '
											<span class="line">
												<span class="arrow-right"></span>
											</span>
										</a>
									</footer>
								</div>
							</article>';

			}

		}

		$output .= '</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_blog_full_width::get_instance();