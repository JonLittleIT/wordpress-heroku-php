<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_biography {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_biography', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_biography__first_content = $aqura_biography__second_content = $aqura_biography__person = $aqura_biography__signature = '';

		extract( shortcode_atts( array(
			'aqura_biography__first_content'	=> '',
			'aqura_biography__second_content' 	=> '',
			'aqura_biography__person' 			=> '',
			'aqura_biography__signature' 		=> '',
		), $atts ) );

		$output .= '<div class="bio-type-3" >
						<div class="my-story">
							<div class="row">
								<div class="col-sm-6">
									<p>
										' . esc_html( $aqura_biography__first_content ) . '
									</p>
								</div>
								<div class="col-sm-6">
									<p>
										' . esc_html( $aqura_biography__second_content ) . '
									</p>
									<div class="signature">
										<a>' . esc_html( $aqura_biography__person ) . ':</a>
										<div class="img-signature">
											<img src="' . wp_get_attachment_url( $aqura_biography__signature ) . '" alt="' . esc_html( 'Signature' , 'aqura' ) . '">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_biography::get_instance();