<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_scale_background {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_scale_background', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_scale_background__image = '';

		extract( shortcode_atts( array(
			'aqura_scale_background__image'	=> '',
		), $atts ) );

		$aqura_bg_image = wp_get_attachment_url( $aqura_scale_background__image );

		$output .= '<div class="scale-bgk" style="background-image: url(' . esc_url( $aqura_bg_image ) . ');">
		</div>';

		return $output;
	}

}
Aqura_scale_background::get_instance();