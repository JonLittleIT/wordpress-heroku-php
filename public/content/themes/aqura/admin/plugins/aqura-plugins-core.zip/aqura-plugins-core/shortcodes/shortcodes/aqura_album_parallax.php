<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_album_parallax {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_album_parallax', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_album_parallax__album = $aqura_section_title__description = $aqura_album_parallax__title__font_size = $aqura_album_parallax__color_title = $aqura_album_parallax__description__font_size = $aqura_album_parallax__color_description = $aqura_album_parallax__footer__font_size = $aqura_album_parallax__color_footer = '';

		extract( shortcode_atts( array(
			'aqura_album_parallax__album'					=> '',
			'aqura_section_title__description'				=> '',
			'aqura_album_parallax__title__font_size'		=> '',
			'aqura_album_parallax__color_title'				=> '',
			'aqura_album_parallax__description__font_size'	=> '',
			'aqura_album_parallax__color_description'		=> '',
			'aqura_album_parallax__footer__font_size'		=> '',
			'aqura_album_parallax__color_footer'			=> '',
		), $atts ) );

		$args = array(
			'p'         => $aqura_album_parallax__album,
			'post_type' => 'albums'
		);

		global $wp_query;

		$aqura_actual_album = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $aqura_actual_album;

		if ( $aqura_actual_album->have_posts() ) {
			while ( $aqura_actual_album->have_posts() ) : $aqura_actual_album->the_post();

				$aqura_header_image__bg = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );

				$aqura_album_last_fm 	= rwmb_meta('aqura_album_options__last_fm');
				$aqura_album_soundcloud = rwmb_meta('aqura_album_options__soundcloud');
				$aqura_album_itunes 	= rwmb_meta('aqura_album_options__itunes');
				$aqura_album_spotify 	= rwmb_meta('aqura_album_options__spotify');
				$aqura_album_amazon 	= rwmb_meta('aqura_album_options__amazon');
				$aqura_album_beatport 	= rwmb_meta('aqura_album_options__beatport');
	        
	        	$output .= '<div class="full-bgk-parallax-albums" style="background-image:url(' . esc_url( $aqura_header_image__bg ) . ');">
								<div class="content">
									<h2 style="font-size: ' . esc_attr( $aqura_album_parallax__title__font_size ) . '; color: ' . esc_attr( $aqura_album_parallax__color_title ) . ';">
										' . get_the_title() . '
									</h2>
									<div class="content-info">
										<p style="font-size: ' . esc_attr( $aqura_album_parallax__description__font_size ) . '; color: ' . esc_attr( $aqura_album_parallax__color_description ) . ';">
											' . esc_html( $aqura_section_title__description ) . '
										</p>
										<div class="social-icons">';
										if ( ($aqura_album_last_fm != '') || ($aqura_album_soundcloud != '') || ($aqura_album_itunes != '') || ($aqura_album_spotify != '') || ($aqura_album_amazon != '') || ($aqura_album_beatport != '') ):
												if ( $aqura_album_last_fm != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_last_fm ) . '" class="icon-button shopIcon"  target="_blank"><i class="fa fa-lastfm" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
												if ( $aqura_album_soundcloud != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_soundcloud ) . '" class="icon-button shopIcon" target="_blank"><i class="fa fa-soundcloud" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
												if ( $aqura_album_itunes != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_itunes ) . '" class="icon-button shopIcon" target="_blank"><i class="fa fa-apple" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
												if ( $aqura_album_spotify != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_spotify ) . '" class="icon-button shopIcon" target="_blank"><i class="fa fa-spotify" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
												if ( $aqura_album_amazon != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_amazon ) . '" class="icon-button shopIcon" target="_blank"><i class="fa fa-amazon" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
												if ( $aqura_album_beatport != '' ):
													$output .= '<a href="' . esc_url( $aqura_album_beatport ) . '" class="icon-button shopIcon" target="_blank"><i class="fa fa-headphones" style="color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';"></i><span></span></a>';
												endif;
											endif;
											$output .= '<a href="#" class="details-social" style="font-size: ' . esc_attr( $aqura_album_parallax__footer__font_size ) . '; color: ' . esc_attr( $aqura_album_parallax__color_footer ) . ';">' . esc_html__( "Details" , "aqura" ) . ' <i class="fa fa-angle-right"></i></a>
										</div>
									</div>
								</div>
							</div>';
	    	
	    	endwhile;
	    }

	    wp_reset_query();

		return $output;
	}

}
Aqura_album_parallax::get_instance();