<?php
/**
 * Plugin Name: AQURA Plugins Core
 * Plugin URI: https://themeforest.net/user/theme-brothers/portfolio
 * Description: AQURA Plugins Core includes some important pre-packed plugins for the AQURA Theme.
 * Version: 1.0.0
 * Author: Theme-Brothers
 * Author URI: https://themeforest.net/user/theme-brothers/portfolio
 * License: GPL2+
 */

 // File Security Check
 if ( ! defined( 'ABSPATH' ) ) { exit; }

class AQURA_plugins_core {

	protected static $instance = null;

	private function __construct() {

		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'mailchimp-api/mailchimp-api.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'aqura-demo-import/one-click-demo-import.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'meta-box-group/meta-box-group.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'meta-box-show-hide/meta-box-show-hide.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'meta-box-tabs/meta-box-tabs.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'post-types/aqura-post-types.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/shortcodes.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'visual-composer/visual-composer.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'widgets/widgets.php' );

	}

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}
}

