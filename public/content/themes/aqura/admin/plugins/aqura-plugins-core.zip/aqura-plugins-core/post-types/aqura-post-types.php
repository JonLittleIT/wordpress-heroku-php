<?php

/**
 * Plugin Name: Aqura PostTypes
 */

// File Security Check
if ( defined( 'ABSPATH' ) ) {


	class AQURA_PostTypes {

		protected static $instance = null;

		private function __construct() {

			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'post-types/aqura-post-types__albums.php');
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'post-types/aqura-post-types__events.php');
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'post-types/aqura-post-types__gallery.php');

		}

		/**
		 * Return an instance of this class.
		 *
		 * @since     1.0.0
		 *
		 * @return    object  A single instance of this class.
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}

	}

	AQURA_PostTypes::get_instance();

}