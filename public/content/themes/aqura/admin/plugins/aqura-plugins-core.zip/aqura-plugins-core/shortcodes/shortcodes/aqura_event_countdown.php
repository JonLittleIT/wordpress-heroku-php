<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_event_countdown {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_event_countdown', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_event_countdown__title = $aqura_event_countdown__title__font_size = $aqura_event_countdown__title__margin_bottom = $aqura_event_countdown__title__color = $aqura_event_countdown__banner = $aqura_event_countdown__banner__margin_bottom = $aqura_event_countdown__link = $aqura_event_countdown__date = $aqura_event_countdown__date__font_size = '';

		extract( shortcode_atts( array(
			'aqura_event_countdown__title'					=> '',
			'aqura_event_countdown__title__font_size' 		=> '',
			'aqura_event_countdown__title__margin_bottom' 	=> '',
			'aqura_event_countdown__title__color' 			=> '',
			'aqura_event_countdown__banner'					=> '',
			'aqura_event_countdown__banner__margin_bottom'	=> '',
			'aqura_event_countdown__link'					=> '',
			'aqura_event_countdown__date'					=> '',
		), $atts ) );

		$aqura_event_countdown__banner 	= wp_get_attachment_url( $aqura_event_countdown__banner );

		$output .= '<div class="next-event ">
						<div class="next-event-title">
							<h1 style="line-height:initial;margin-bottom:' . esc_attr( $aqura_event_countdown__title__margin_bottom ) . ';font-size:' . esc_attr( $aqura_event_countdown__title__font_size ) . ';color:' . esc_attr( $aqura_event_countdown__title__color ) . ';">' . esc_html( $aqura_event_countdown__title ) . '</h1>
						</div>
						<div class="next-event-info" style="margin-bottom:' . esc_attr( $aqura_event_countdown__banner__margin_bottom ) . ';">
							<a href="' . esc_html( $aqura_event_countdown__link ) . '" class="image"><img src="' . esc_url($aqura_event_countdown__banner ) . '" alt="' . esc_attr( $aqura_event_countdown__title ) . '"></a>
						</div>
						<div id="clock" class="clearfix" data-countdown="' . esc_attr( $aqura_event_countdown__date ) . '"></div>
					</div>';

		return $output;
	}

}
Aqura_event_countdown::get_instance();