<?php

// File Security Check

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Creating the widget 

class WP_instagram_feed extends WP_Widget {

	protected $defaults;

	function __construct() {

		$this->defaults = array(
            'title'  => esc_html__( 'Istageam' , 'aqura' ),
            'instageam_number' => 9,
        );

		parent::__construct(

			// Base ID of your widget
			'WP_instagram_feed', 

			// Widget name will appear in UI
			esc_html__('Instagram Feed', 'aqura')

		);

	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $aqura_args, $instance ) {

		echo balanceTags($aqura_args['before_widget']);

		$aqura_title = apply_filters( 'widget_title', $instance['title'] );
		$aqura_instageam_number = $instance['instageam_number'] ? $instance['instageam_number'] : $this->defaults['instageam_number'];

		if ( ! empty( $aqura_title ) )
			echo balanceTags($aqura_args['before_title']) . esc_html($aqura_title) . balanceTags($aqura_args['after_title']);

		global $aqura_data;

		$aqura_json = wp_remote_get("https://api.instagram.com/v1/users/self/?access_token={$aqura_data['aqura_theme__api__instagram']}");
		if ( strpos($aqura_json['body'], '"id"') !== false ) {
			$aqura_data_json = json_decode($aqura_json['body']);

			$user_id = $aqura_data_json->data->id;

			$aqura_json = wp_remote_get("https://api.instagram.com/v1/users/{$aqura_data['aqura_theme__api__instagram_user']}/media/recent/?count={$aqura_instageam_number}&access_token={$aqura_data['aqura_theme__api__instagram']}");
			$aqura_data_json = json_decode($aqura_json['body']);

			$aqura_images = array();
			foreach( $aqura_data_json->data as $user_data ) {
				$aqura_images[] = (array) $user_data->images;
				$aqura_links[] = (array) $user_data->link;
			}

			$aqura_standard = array_map( function( $item ) {
				return $item['standard_resolution']->url;
			}, $aqura_images );

			$i = 0;

			echo '<div class="widget-insta">
					<ul class="clearfix">';
						foreach( $aqura_standard as $img_url ) {
					echo '<li>
							<a href="' . esc_url( $aqura_links[$i][0] ) . '" class="insta-img">
								<img src="' . esc_url( $img_url ) . '" alt="' . esc_html__( 'instagram' , 'aqura' ) . '">
							</a>
						</li>';
							$i++;
						}
				echo '</ul>
				</div>';

		}

		echo balanceTags($aqura_args['after_widget']);

	}


	// Widget Backend 
	public function form( $instance ) {

		if ( isset( $instance[ 'title' ] ) ) {
			$aqura_title = $instance[ 'title' ];
		} else {
			$aqura_title = esc_html__( 'Instagram' , 'aqura');
		};

		if ( isset( $instance[ 'instageam_number' ] ) ) {
			$aqura_instageam_number = $instance[ 'instageam_number' ];
		} else {
			$aqura_instageam_number = $this->defaults['instageam_number'];
		}; ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">
					<?php esc_html_e( 'Title:' , 'aqura' ); ?>
			</label> 
			<input class="widefat"
				id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" 
				name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" 
				value="<?php echo esc_attr( $aqura_title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">
					<?php esc_html_e( 'Title:' , 'aqura' ); ?>
			</label> 
			<input class="widefat"
				type="number"
				id="<?php echo esc_attr($this->get_field_id( 'instageam_number' )); ?>" 
				name="<?php echo esc_attr($this->get_field_name( 'instageam_number' )); ?>" type="text" 
				value="<?php echo esc_attr( $aqura_instageam_number ); ?>" />
		</p>
<?php }

	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : $this->defaults['title'];
		$instance['instageam_number'] = ( ! empty( $new_instance['instageam_number'] ) ) ? strip_tags( $new_instance['instageam_number'] ) : $this->defaults['instageam_number'];
		return $instance;
	}

} // Class WP_instagram_feed ends here
