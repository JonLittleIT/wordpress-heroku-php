<?php 

// File Security Check

if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'widgets/widget-instagram-feed.php' );
require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'widgets/widget-popular-articles.php' );

add_action( 'widgets_init', 'aqura_load_widgets' );

function aqura_load_widgets() {
    register_widget( 'WP_popular_articles' );
    register_widget( 'WP_instagram_feed' );
}