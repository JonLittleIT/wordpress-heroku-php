<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_blog_masonry_small {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_blog_masonry_small', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_blog_masonry_small__number = $aqura_blog_masonry_small__title__font_size = $aqura_blog_masonry_small__filter = $aqura_blog_masonry_small__bg = $aqura_blog_masonry_small__cols = '';

		extract( shortcode_atts( array(
			'aqura_blog_masonry_small__number' 				=> '3',
			'aqura_blog_masonry_small__title__font_size' 	=> '',
			'aqura_blog_masonry_small__filter' 				=> '',
			'aqura_blog_masonry_small__bg' 					=> 'rgba(242, 242, 242, 0.7)',
			'aqura_blog_masonry_small__cols' 				=> 'three',
		), $atts ) );

		if ( $aqura_blog_masonry_small__cols == 'one' ) {
			$aqura_blog_masonry_small__cols = 'col-sm-12';
		} elseif ( $aqura_blog_masonry_small__cols == 'two' ) {
			$aqura_blog_masonry_small__cols = 'col-sm-6';
		} elseif ( $aqura_blog_masonry_small__cols == 'three' ) {
			$aqura_blog_masonry_small__cols = 'col-sm-4';
		} elseif ( $aqura_blog_masonry_small__cols == 'four' ) {
			$aqura_blog_masonry_small__cols = 'col-sm-3';
		}

		$aqura_blog_args 		= array( 'taxonomy' => 'category' );
		$aqura_blog_categories = get_categories($aqura_blog_args);

		global $wp_query;

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
		else { $paged = 1; }

		$args = array(
			'post_status'		=> 'publish',
			'orderby' 			=> 'date',
			'order' 			=> 'DESC',
			'paged'				=> $paged,
			'posts_per_page'	=> $aqura_blog_masonry_small__number,
		);

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$output .= '<div class="blog-type-1-masonry">
						<div class="blog-type-1-filter">
							<div class="row">';
								if ( $aqura_blog_masonry_small__filter == true ) {
					$output .= '<div class="col-sm-12">
									<div class="categories">
										<ul class="clearfix" data-option-key="filter">
											<li><a><i class="fa fa-filter"></i></a></li>
											<li><a class="selected" data-option-value="*">All</a></li>';
											foreach( $aqura_blog_categories as $category ) :
								$output .= '<li>';
									$output .= '<a data-option-value=".blog-category-' . esc_attr($category->slug) . '">';
										$output .= esc_html($category->name);
									$output .= '</a>';
								$output .= '</li>';
											endforeach;
							$output .= '</ul>
									</div>
								</div>';
								}
					$output .= '<div class="col-sm-12">';
									if ( $aqura_blog_masonry_small__filter == true ) {
						$output .= '<div class="aqura-filter-content">';
									}
							$output .= '<ul class="clearfix">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();

				$aqura_the_permalink = get_the_permalink();

				$aqura_categories_classes = '';
				$aqura_blog_item_categories = get_the_terms( get_the_ID(), 'category' );
				if( ! empty( $aqura_blog_item_categories ) ) {
					foreach( $aqura_blog_item_categories as $category ) {
						$aqura_categories_classes .= ' blog-category-' . $category->slug;
					}
				}

				$aqura_post__options__article_type__the_type 			= rwmb_meta( 'aqura_post__options__article_type__the_type' );
				$aqura_post__options__article_type__soundcloud_track_id = rwmb_meta( 'aqura_post__options__article_type__soundcloud_track_id' );
				$aqura_post__options__article_type__video_id 			= rwmb_meta( 'aqura_post__options__article_type__video_id' );
				$aqura_post__options__article_type__quote_text 			= rwmb_meta( 'aqura_post__options__article_type__quote_text' );
				$aqura_post__options__article_type__quote_icon 			= rwmb_meta( 'aqura_post__options__article_type__quote_icon' );
				$aqura_post__options__article_type__quote_author 		= rwmb_meta( 'aqura_post__options__article_type__quote_author' );
				$aqura_post__options__article_type__gallery_images 		= rwmb_meta( 'aqura_post__options__article_type__gallery_images' , array( 'size' => 'thumbnail' ) );

				$output .= '<li class="' . esc_attr( $aqura_blog_masonry_small__cols . ' ' . $aqura_categories_classes ) . ' col-xs-12">
								<article style="background-color: ' . esc_attr( $aqura_blog_masonry_small__bg ) . ';">
									<figure>';
										if ( $aqura_post__options__article_type__the_type === "standard" ):

									$output .= '<a href="' . esc_url( $aqura_the_permalink ) . '" class="image">
													' . get_the_post_thumbnail(get_the_ID(), 'full') . '
												</a>';

										elseif ( $aqura_post__options__article_type__the_type === "soundcloud" ):
											if ( $aqura_post__options__article_type__soundcloud_track_id != "" ):

									$output .= '<iframe class="single-article-top-format-iframe" width="100" height="53"  src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . esc_attr($aqura_post__options__article_type__soundcloud_track_id) . '&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>';

											endif;
										elseif ( $aqura_post__options__article_type__the_type === "youtube" ) :
											if ( $aqura_post__options__article_type__video_id != "" ):

									$output .= '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . esc_attr($aqura_post__options__article_type__video_id) . '" allowfullscreen></iframe>';

											endif;
										elseif ( $aqura_post__options__article_type__the_type === "vimeo" ) :
											if ( $aqura_post__options__article_type__video_id != "" ):

									$output .= '<iframe src="https://player.vimeo.com/video/' . esc_attr($aqura_post__options__article_type__video_id) . '?title=0&byline=0&portrait=0" allowfullscreen></iframe>';

											endif;
										elseif ( $aqura_post__options__article_type__the_type === "quote" ) :
											if ( $aqura_post__options__article_type__quote_text !== "" ):

									$output .= '<div class="blog-single-type-2">
													<div class="grid-item">
														<div class="featured-area" style="background: none;">
															<div class="title">
																<h3><a>“' . esc_html( $aqura_post__options__article_type__quote_text ) . '”</a></h3>';
																if ( $aqura_post__options__article_type__quote_icon !== "" ):

														$output .= '<i class="fa ' . esc_attr( $aqura_post__options__article_type__quote_icon ) . '" aria-hidden="true"></i>';

																endif;
																if ( $aqura_post__options__article_type__quote_author !== "" ):

														$output .= '<a class="author">—' . esc_html(  $aqura_post__options__article_type__quote_author ) . '</a>';

																endif;
												$output .= '</div>
														</div>
													</div>
												</div>';

											endif;
										elseif ( $aqura_post__options__article_type__the_type === "gallery" ) :
											if ( $aqura_post__options__article_type__gallery_images !== "" ):

									$output .= '<div class="owl-carousel custom-arrow-carousel">';
											foreach ( $aqura_post__options__article_type__gallery_images as $image ) {
										$output .= '<div class="item"><img src="' . esc_url( $image["full_url"] ) . '" alt="' . esc_attr( $image["alt"] ) . '"></div>';
											}
									$output .= '</div>';

											endif;
										endif;
						$output .= '</figure>';
									if ( $aqura_post__options__article_type__the_type !== "quote" ) :
						$output .= '<div class="box">
										<header>
											<div class="title">
												<h3><a href="' . esc_url( $aqura_the_permalink ) . '" style="font-size:' . esc_attr( $aqura_blog_masonry_small__title__font_size ) . ';">' . get_the_title() . '</a></h3>
											</div>
											<aside class="post-meta">
												<p>' . get_the_date() . ' ' . aqura_get_posted_by() . '</p>
											</aside>
										</header>
										<div class="article-content">
											<p>' . esc_html(mb_strimwidth(get_the_content(), 0, 200, '...')) . '</p>
										</div>
										<footer>
											<a href="' . esc_url( $aqura_the_permalink ) . '" class="read-more">
												' . esc_html__( "Read More" , "aqura" ) . '
												<span class="line">
													<span class="arrow-right"></span>
												</span>
											</a>
										</footer>
										<div class="overlay-box"></div>
									</div>';
									endif;
					$output .= '</article>
							</li>';

			}

		}

							$output .= '</ul>';
			if ( $aqura_blog_masonry_small__filter == true ) {
						$output .= '</div>';
									}
					$output .= '</div>
							</div>
						</div>
					</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_blog_masonry_small::get_instance();