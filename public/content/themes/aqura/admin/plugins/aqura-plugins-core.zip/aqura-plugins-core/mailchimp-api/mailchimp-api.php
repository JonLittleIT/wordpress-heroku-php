<?php

if ( defined( 'ABSPATH' ) )
{
	class mailchimp_api {

	    protected $prefix = 'mailchimp_api_';

	    public $accordion_instance = array(
	        'id'    => 0,
	        'type'  => '',
	        'tab_id'=> 0,
	    );

	    protected static $instance = null;

	    private function __construct() {

	        add_action( 'after_setup_theme', array( $this, 'includes' ), 2 );

	    }

	    /**
		 * Includes
		 */
		function includes() {

			require plugin_dir_path( __FILE__ ) . 'inc/class-mailchimp-api.php';

		}

	    /**
	     * Return an instance of this class.
	     *
	     * @since     1.0.0
	     *
	     * @return    object    A single instance of this class.
	     */
	    public static function get_instance() {

	        // If the single instance hasn't been set, set it now.
	        if ( null == self::$instance ) {
	            self::$instance = new self;
	        }

	        return self::$instance;
	    }

	}
	mailchimp_api::get_instance();
}
