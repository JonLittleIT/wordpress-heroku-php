<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_albums_disks_grid {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_albums_disks_grid', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_albums_disks_grid__filter = $aqura_albums_disks_grid__number = $aqura_albums_disks_grid__color_title = $aqura_albums_disks_grid__color_label = $aqura_albums_disks_grid__cols = '';

		extract( shortcode_atts( array(
			'aqura_albums_disks_grid__filter'		=> '',
			'aqura_albums_disks_grid__number'		=> 4,
			'aqura_albums_disks_grid__color_title'	=> '',
			'aqura_albums_disks_grid__color_label'	=> '',
			'aqura_albums_disks_grid__cols'			=> 'four',
		), $atts ) );

		if ( $aqura_albums_disks_grid__cols == 'one' ) {
			$aqura_albums_disks_grid__cols = 'col-sm-12';
		} elseif ( $aqura_albums_disks_grid__cols == 'two' ) {
			$aqura_albums_disks_grid__cols = 'col-sm-6';
		} elseif ( $aqura_albums_disks_grid__cols == 'three' ) {
			$aqura_albums_disks_grid__cols = 'col-sm-4';
		} elseif ( $aqura_albums_disks_grid__cols == 'four' ) {
			$aqura_albums_disks_grid__cols = 'col-sm-3';
		}

		$args = array(
			'post_type'		 	=> 'albums',
			'post_status'	  	=> 'publish',
			'posts_per_page'	=> $aqura_albums_disks_grid__number,
		);

		global $wp_query;

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$aqura_ablums_args 		= array( 'taxonomy' => 'albums-category' );
		$aqura_ablums_categories = get_categories($aqura_ablums_args);

		$output .= '<div class="album-type-1-masonry">';
						if ( $aqura_albums_disks_grid__filter == true ) {
			$output .= '<div class="categories">
							<ul class="clearfix" data-option-key="filter">
								<li><a href="#"><i class="fa fa-filter"></i></a></li>
								<li><a href="#" class="selected" data-option-value="*">All</a></li>';
								foreach( $aqura_ablums_categories as $category ) :
								$output .= '<li>';
									$output .= '<a data-option-value=".albums-category-' . esc_attr($category->slug) . '">';
										$output .= esc_html($category->name);
									$output .= '</a>';
								$output .= '</li>';
											endforeach;
							$output .= '</ul>
						</div>';
						}
			$output .= '<div class="aqura-filter-content">
							<ul class="album-covers-1">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();

				$aqura_album_cover 			= rwmb_meta( 'aqura_album_options__album_cover' , array( array( 'limit' => 1 ) , 'size' => 'full' ));
				if ( $aqura_album_cover != '' ) {
				$aqura_album_cover 			= reset( $aqura_album_cover )['url'];
				}
				$aqura_album_label 			= rwmb_meta( 'aqura_album_options__album_label' );

				$aqura_album_permalink 		= get_the_permalink();

				$aqura_categories_classes = '';
				$aqura_albums_item_categories = get_the_terms( get_the_ID(), 'albums-category' );
				if( ! empty( $aqura_albums_item_categories ) ) {
					foreach( $aqura_albums_item_categories as $category ) {
						$aqura_categories_classes .= ' albums-category-' . $category->slug;
					}
				}

					$output .= '<li class="' . esc_attr( $aqura_albums_disks_grid__cols . ' ' . $aqura_categories_classes ) . '">
									<div class="album">
										<span class="vinyl"></span>
										<a href="' . get_the_permalink() . '"><span class="cover cover-1" style="background-image: url(' . esc_url( $aqura_album_cover ) . ');"></span></a>
									</div>
									<div class="info-album-covers-1">
										<h3 class="album-name" style="color: ' . esc_attr( $aqura_albums_disks_grid__color_title ) . ';">' . get_the_title() . '</h3>
										<p class="category" style="color: ' . esc_attr( $aqura_albums_disks_grid__color_label ) . ';">' . esc_html( $aqura_album_label ) . '</p>
									</div>
								</li>';

			}

		}

				$output .= '</ul>';
			$output .= '</div>';
		$output .= '</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_albums_disks_grid::get_instance();