<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_shortcodes {

	protected static $instance = null;

	private function __construct() {

		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_menu_social_icon.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_footer_social_icon.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_section_title.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_big_section_title.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_hero_flipping_words.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_hero_tabs.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_hero_buttons.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_hero_buttons__button.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_header_image.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_albums_disks_grid.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_albums_square.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_albums_square_slide_down.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_album_parallax.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_album_preview.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_bandsintown.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_event_countdown.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_blog_full_width.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_blog_masonry_small.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_blog_masonry_style_02.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_last_tweet_large.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_gallery_images.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_gallery_listing.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_contact_informations.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_contact_form.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_biography.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_featured_platform.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_about_me.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_instagram_carousel.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_instagram_carousel_small.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_parallax_square_images.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_glitch_square_images.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_scale_background.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_stores_available.php' );
		require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'shortcodes/aqura_hero_glitch.php' );

	}

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

}
Aqura_shortcodes::get_instance();