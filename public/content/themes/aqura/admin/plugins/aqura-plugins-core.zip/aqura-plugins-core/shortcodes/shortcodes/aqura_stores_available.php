<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_stores_available {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_stores_available', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_stores_available__title = $aqura_stores_available__image = '';

		extract( shortcode_atts( array(
			'aqura_stores_available__title'	=> esc_html__( 'Title', 'aqura' ),
			'aqura_stores_available__image'	=> '',
		), $atts ) );

		$aqura_stores_available__images = explode(',', $aqura_stores_available__image);

		$output .= '<div class="music-store-type-2">
						<div class="store-title">
							<h1>
								<a>
									' . $aqura_stores_available__title . '
								</a>
							</h1>
						</div>
						<div class="links">';
							foreach( $aqura_stores_available__images as $image_id ){
								$image = wp_get_attachment_url( $image_id );
					$output .= '<a class="badge">
								    <img src="' . esc_url( $image ) . '" alt="">
								</a>';
							}
			$output .= '</div>
					</div>';

		return $output;
	}

}
Aqura_stores_available::get_instance();