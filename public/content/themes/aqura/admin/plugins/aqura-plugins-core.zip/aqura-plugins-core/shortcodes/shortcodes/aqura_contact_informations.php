<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_contact_informations {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_contact_informations', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_contact_informations__title = $aqura_contact_informations__title__font_size = $aqura_contact_informations__address = $aqura_contact_informations__adescription = $aqura_contact_informations__email = $aqura_contact_informations__phone = $aqura_contact_informations__fax = '';

		extract( shortcode_atts( array(
			'aqura_contact_informations__title'					=> esc_html__( 'CONTACT INFORMATION' , 'aqura' ),
			'aqura_contact_informations__title__font_size' 		=> '',
			'aqura_contact_informations__address' 				=> '',
			'aqura_contact_informations__adescription' 			=> '',
			'aqura_contact_informations__email'					=> '',
			'aqura_contact_informations__phone'					=> '',
			'aqura_contact_informations__fax'					=> '',
		), $atts ) );

		$output .= '<div class="contact-type-1">
						<aside class="contact-type-1-aside">
							<h4 style="font-size: ' . esc_attr( $aqura_contact_informations__title__font_size ) . ';">' . esc_html( $aqura_contact_informations__title ) . '</h4>
							<div class="street">
								<p>' . esc_html( $aqura_contact_informations__address ) . '</p>
							</div>
							<div class="description">
								<p>' . esc_html( $aqura_contact_informations__adescription ) . '</p>
							</div>
							<div class="contact-info">
								<ul class="clearfix">';
								if ( $aqura_contact_informations__email != '' ) {
									$output .= '<li>' . esc_html__( 'Email' , 'aqura' ) . '<a href="mailto:' . esc_attr( $aqura_contact_informations__email ) . '">' . esc_html( $aqura_contact_informations__email ) . '</a></li>';
								}
								if ( $aqura_contact_informations__phone != '' ) {
									$output .= '<li>' . esc_html__( 'Phone' , 'aqura' ) . '<a href="tel:' . esc_attr( $aqura_contact_informations__phone ) . '">' . esc_html( $aqura_contact_informations__phone ) . '</a></li>';
								}
								if ( $aqura_contact_informations__fax != '' ) {
									$output .= '<li>' . esc_html__( 'Fax' , 'aqura' ) . '<a>' . esc_html( $aqura_contact_informations__fax ) . '</a></li>';
								}
					$output .= '</ul>
							</div>
						</aside>
					</div>';

		return $output;
	}

}
Aqura_contact_informations::get_instance();