<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_album_preview {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_album_preview', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_album_preview__album = $aqura_album_preview__tracklist_title = $aqura_album_preview__albums_url  = '';

		extract( shortcode_atts( array(
			'aqura_album_preview__album' 			=> '',
			'aqura_album_preview__tracklist_title' 	=> esc_html__( 'Tracklist' , 'aqura' ),
			'aqura_album_preview__albums_url' 		=> '',
		), $atts ) );

		$args = array(
			'p'         => $aqura_album_preview__album,
			'post_type' => 'albums'
		);

		global $wp_query;

		$aqura_actual_album = new WP_Query($args);

		// Pagination fix
		$temp_query  = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $aqura_actual_album;

		if ( $aqura_actual_album->have_posts() ) {
			while ( $aqura_actual_album->have_posts() ) : $aqura_actual_album->the_post();

				$aqura_album_cover 			= rwmb_meta( 'aqura_album_options__album_cover' , array( array( 'limit' => 1 ) , 'size' => 'full' ));
				if ( $aqura_album_cover != '' ) {
					$aqura_album_cover 			= reset( $aqura_album_cover )['url'];
				}

				$aqura_album_last_fm 	= rwmb_meta('aqura_album_options__last_fm');
				$aqura_album_soundcloud = rwmb_meta('aqura_album_options__soundcloud');
				$aqura_album_itunes 	= rwmb_meta('aqura_album_options__itunes');
				$aqura_album_spotify 	= rwmb_meta('aqura_album_options__spotify');
				$aqura_album_amazon 	= rwmb_meta('aqura_album_options__amazon');
				$aqura_album_beatport 	= rwmb_meta('aqura_album_options__beatport');

				$aqura_tracks = rwmb_meta('aqura_album_options__album_tracks');
				$aqura_tracks_i = 0;

	$output .= '<div class="album-covers-4 album-covers-4-cherry">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-3">
								<div class="">
									<div class="player-canvas">
										<a href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
									</div>
									<div class="available-on">
										<ul class="clearfxi">';
										if ( ($aqura_album_last_fm != '') || ($aqura_album_soundcloud != '') || ($aqura_album_itunes != '') || ($aqura_album_spotify != '') || ($aqura_album_amazon != '') || ($aqura_album_beatport != '') ):
											if ( $aqura_album_last_fm != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_last_fm ) . '">' . esc_html__( 'Last FM' , 'aqura' ) . '</a></li>';
											endif;
											if ( $aqura_album_soundcloud != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_soundcloud ) . '">' . esc_html__( 'SoundCloud' , 'aqura' ) . '</a></li>';
											endif;
											if ( $aqura_album_itunes != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_itunes ) . '">' . esc_html__( 'Itines' , 'aqura' ) . '</a></li>';
											endif;
											if ( $aqura_album_spotify != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_spotify ) . '">' . esc_html__( 'Spotify' , 'aqura' ) . '</a></li>';
											endif;
											if ( $aqura_album_amazon != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_amazon ) . '">' . esc_html__( 'Amazon' , 'aqura' ) . '</a></li>';
											endif;
											if ( $aqura_album_beatport != '' ):
												$output .= '<li>' . esc_html__( 'On' , 'aqura' ) . ' <a href="' . esc_url( $aqura_album_beatport ) . '">' . esc_html__( 'Beatport' , 'aqura' ) . '</a></li>';
											endif;
										endif;
							$output .= '</ul>
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="album-thumbnail">';
									if ( $aqura_album_cover != '' ):
							$output .= '<a href="' . get_the_permalink() . '"><img src="' . esc_url( $aqura_album_cover ) . '" alt="' . get_the_title() . '"></a>';
									endif;
					$output .= '</div>
							</div>
							<div class="col-sm-3">
								<div class="tracklist">
									<h4>' . esc_html( $aqura_album_preview__tracklist_title ) . '</h4>
									<ul class="clearfix">';
									foreach ($aqura_tracks as $key => $aqura_track) {
										$aqura_tracks_i++;
										if ( $aqura_tracks_i < 10 ) {
											$aqura_tracks_i = '0' . $aqura_tracks_i;
										}
							$output .= '<li>' . esc_html( $aqura_tracks_i ) . '<a>' . esc_html($aqura_track['aqura_album_options__track-name']) . '</a></li>';
									}
						$output .= '</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-12">
							<div class="album-covers-4-footer">
								' . aqura_get_album_next_prev_02(true);
								if ( $aqura_album_preview__albums_url != '' ) {
					$output .= '<div class="view-more">
									<a href="' . esc_url( $aqura_album_preview__albums_url ) . '">
										<span class="square"></span>
										<span class="square"></span>
										<span class="square"></span>
										<span class="square"></span>
									</a>
								</div>';
								}
					$output .= aqura_get_album_next_prev_02(false) . '
							</div>
						</div>
					</div>
				</div>';
	    	
	    	endwhile;
	    }

	    wp_reset_query();

		return $output;
	}

}
Aqura_album_preview::get_instance();