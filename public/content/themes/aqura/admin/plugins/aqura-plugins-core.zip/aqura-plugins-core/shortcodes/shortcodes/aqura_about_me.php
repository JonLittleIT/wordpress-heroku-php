<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_about_me {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_about_me', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_about_me__title = $aqura_about_me__story = $aqura_about_me__images = '';

		extract( shortcode_atts( array(
			'aqura_about_me__title'		=> '',
			'aqura_about_me__story'		=> '',
			'aqura_about_me__images'	=> '',
		), $atts ) );

		$aqura_about_me__images = explode(',', $aqura_about_me__images);

		$output .= '<div class="about-me-flore">
						<div class="col-sm-8">
							<div class="about-me-container">
								<div class="curtain-image-container section-radius">';
								foreach ($aqura_about_me__images as $image_ID) {
									$aqura_image_url = wp_get_attachment_url( $image_ID , 'full' );
									$output .= '<div class="curtain-image" style="background-image: url(' . esc_url( $aqura_image_url ) . ');"></div>';
								}
					$output .= '</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="title">
								<h2>' . esc_html( $aqura_about_me__title ) . '</h2>
							</div>
							<div class="about-flore-text">
								<p>
								' . esc_html( $aqura_about_me__story ) . '
								</p>
							</div>
						</div>
					</div>';

		return $output;
	}

}
Aqura_about_me::get_instance();