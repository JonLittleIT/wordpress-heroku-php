<?php

// Register Custom Post Type
function aqura_gallery() {

	$labels = array(
		'name'                  => _x( 'Galleries', 'Post Type General Name', 'aqura' ),
		'singular_name'         => _x( 'Gallery', 'Post Type Singular Name', 'aqura' ),
		'menu_name'             => __( 'Gallery', 'aqura' ),
		'name_admin_bar'        => __( 'Gallery', 'aqura' ),
		'archives'              => __( 'Gallery Archives', 'aqura' ),
		'parent_item_colon'     => __( 'Parent Gallery:', 'aqura' ),
		'all_items'             => __( 'All Galleries', 'aqura' ),
		'add_new_item'          => __( 'Add New Gallery', 'aqura' ),
		'add_new'               => __( 'Add New', 'aqura' ),
		'new_item'              => __( 'New Gallery', 'aqura' ),
		'edit_item'             => __( 'Edit Gallery', 'aqura' ),
		'update_item'           => __( 'Update Gallery', 'aqura' ),
		'view_item'             => __( 'View Gallery', 'aqura' ),
		'search_items'          => __( 'Search Gallery', 'aqura' ),
		'not_found'             => __( 'Not found', 'aqura' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'aqura' ),
		'featured_image'        => __( 'Featured Image', 'aqura' ),
		'set_featured_image'    => __( 'Set featured image', 'aqura' ),
		'remove_featured_image' => __( 'Remove featured image', 'aqura' ),
		'use_featured_image'    => __( 'Use as featured image', 'aqura' ),
		'insert_into_item'      => __( 'Insert into item', 'aqura' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'aqura' ),
		'items_list'            => __( 'Gallery list', 'aqura' ),
		'items_list_navigation' => __( 'Items list navigation', 'aqura' ),
		'filter_items_list'     => __( 'Filter items list', 'aqura' ),
	);
	$args = array(
		'label'                 => __( 'Gallery', 'aqura' ),
		'description'           => __( 'Aqura Gallery', 'aqura' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-format-gallery',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'gallery', $args );

}
add_action( 'init', 'aqura_gallery', 0 );