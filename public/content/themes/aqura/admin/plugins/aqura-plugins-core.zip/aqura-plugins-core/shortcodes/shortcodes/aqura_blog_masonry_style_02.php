<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_blog_masonry_style_02 {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_blog_masonry_style_02', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_blog_masonry_style_02__number = $aqura_blog_masonry_style_02__title__font_size = $aqura_blog_masonry_style_02__bg = $aqura_blog_masonry_style_02__cols = '';

		extract( shortcode_atts( array(
			'aqura_blog_masonry_style_02__number' 				=> '3',
			'aqura_blog_masonry_style_02__title__font_size' 	=> '',
			'aqura_blog_masonry_style_02__bg' 					=> 'rgba(255, 255, 255, 1)',
			'aqura_blog_masonry_style_02__cols' 				=> 'three',
		), $atts ) );

		if ( $aqura_blog_masonry_style_02__cols == 'one' ) {
			$aqura_blog_masonry_style_02__cols = 'col-sm-12';
		} elseif ( $aqura_blog_masonry_style_02__cols == 'two' ) {
			$aqura_blog_masonry_style_02__cols = 'col-sm-6';
		} elseif ( $aqura_blog_masonry_style_02__cols == 'three' ) {
			$aqura_blog_masonry_style_02__cols = 'col-sm-4';
		} elseif ( $aqura_blog_masonry_style_02__cols == 'four' ) {
			$aqura_blog_masonry_style_02__cols = 'col-sm-3';
		}

		global $wp_query;

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
		else { $paged = 1; }

		$args = array(
			'post_status'		=> 'publish',
			'orderby' 			=> 'date',
			'order' 			=> 'DESC',
			'paged'				=> $paged,
			'posts_per_page'	=> $aqura_blog_masonry_style_02__number,
		);

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$output .= '<div class="blog-type-3-masonry">
						<div class="container-fluid">
							<div class="blog-type-3-masonry-content">
								<ul class="clearfix fix-margin">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();

				$aqura_the_permalink = get_the_permalink();

				$aqura_categories_classes = '';
				$aqura_blog_item_categories = get_the_terms( get_the_ID(), 'category' );
				if( ! empty( $aqura_blog_item_categories ) ) {
					foreach( $aqura_blog_item_categories as $category ) {
						$aqura_categories_classes .= ' blog-category-' . $category->slug;
					}
				}

				$aqura_post__options__article_type__the_type 			= rwmb_meta( 'aqura_post__options__article_type__the_type' );
				$aqura_post__options__article_type__soundcloud_track_id = rwmb_meta( 'aqura_post__options__article_type__soundcloud_track_id' );
				$aqura_post__options__article_type__video_id 			= rwmb_meta( 'aqura_post__options__article_type__video_id' );
				$aqura_post__options__article_type__quote_text 			= rwmb_meta( 'aqura_post__options__article_type__quote_text' );
				$aqura_post__options__article_type__quote_icon 			= rwmb_meta( 'aqura_post__options__article_type__quote_icon' );
				$aqura_post__options__article_type__quote_author 		= rwmb_meta( 'aqura_post__options__article_type__quote_author' );
				$aqura_post__options__article_type__gallery_images 		= rwmb_meta( 'aqura_post__options__article_type__gallery_images' , array( 'size' => 'thumbnail' ) );

				$output .= '<li class="col-sm-4 grid-item">
								<article>';
									if ( $aqura_post__options__article_type__the_type === "standard" ):
						$output .= '<figure>
										<a href="' . esc_url( $aqura_the_permalink ) . '" class="image">
											' . get_the_post_thumbnail(get_the_ID(), 'full') . '
										</a>
									</figure>';
									elseif ( $aqura_post__options__article_type__the_type === "soundcloud" ):
										if ( $aqura_post__options__article_type__soundcloud_track_id != "" ):

							$output .= '<iframe class="single-article-top-format-iframe" width="100" height="53"  src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . esc_attr($aqura_post__options__article_type__soundcloud_track_id) . '&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "youtube" ) :
										if ( $aqura_post__options__article_type__video_id != "" ):

							$output .= '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . esc_attr($aqura_post__options__article_type__video_id) . '" allowfullscreen></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "vimeo" ) :
										if ( $aqura_post__options__article_type__video_id != "" ):

							$output .= '<iframe src="https://player.vimeo.com/video/' . esc_attr($aqura_post__options__article_type__video_id) . '?title=0&byline=0&portrait=0" allowfullscreen></iframe>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "quote" ) :
										if ( $aqura_post__options__article_type__quote_text !== "" ):

							$output .= '<div class="featured-area">
											<ul class="categories">';
											foreach ( get_the_category(get_the_ID()) as $category) {
									$output .= '<li><a href="' . get_category_link( $category->term_id ) . '">' . esc_html( $category->cat_name ) . '</a></li>';
											}
								$output .= '</ul>
											<div class="title">
												<h3><a href="' . esc_url( $aqura_the_permalink ) . '">“' . esc_html( $aqura_post__options__article_type__quote_text ) . '”</a></h3>';
												if ( $aqura_post__options__article_type__quote_icon !== "" ):

										$output .= '<i class="fa ' . esc_attr( $aqura_post__options__article_type__quote_icon ) . '" aria-hidden="true"></i>';

												endif;
									$output .= '<a href="' . esc_url( $aqura_the_permalink ) . '" class="author">—Ken Adams</a>
											</div>
										</div>';

										endif;
									elseif ( $aqura_post__options__article_type__the_type === "gallery" ) :
										if ( $aqura_post__options__article_type__gallery_images !== "" ):

							$output .= '<div class="owl-carousel custom-arrow-carousel">';
									foreach ( $aqura_post__options__article_type__gallery_images as $image ) {
								$output .= '<div class="item"><img src="' . esc_url( $image["full_url"] ) . '" alt="' . esc_attr( $image["alt"] ) . '"></div>';
									}
							$output .= '</div>';

										endif;
									endif;
									if ( $aqura_post__options__article_type__the_type !== "quote" ) :
						$output .= '<div class="box">
										<header>
											<aside class="post-meta-categories">';
												foreach ( get_the_category(get_the_ID()) as $category) {
										$output .= '<a href="' . get_category_link( $category->term_id ) . '">' . esc_html( $category->cat_name ) . '</a>';
												}
								$output .= '</aside>
											<div class="title">
												<h4><a href="' . esc_url( $aqura_the_permalink ) . '">' . get_the_title() . '</a></h4>
											</div>
										</header>
										<div class="article-content">
											<p>' . esc_html(mb_strimwidth(get_the_content(), 0, 200, '...')) . '</p>
										</div>
										<footer>
											<aside class="post-meta">
												<a>' . get_the_author() . ' ' . esc_html__( "on" , "aqura" ) . ' <span>' . get_the_date() . '</span></a>
											</aside>
											<div class="like-comm">
												<a href="' . esc_url( $aqura_the_permalink ) . '"><i class="fa fa-comment-o"></i><span>' . get_comments_number(get_the_ID()) . '</span></a>
											</div>
										</footer>
									</div>';
									endif;
					$output .= '</article>
							</li>';

			}

		}

					$output .= '</ul>
							</div>
						</div>
					</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_blog_masonry_style_02::get_instance();