<?php
/**
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


class Aqura_gallery_listing {

	protected static $instance = null;

	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'aqura_gallery_listing', array( &$this, 'shortcode' ) );
	}

	public function shortcode( $atts, $content = null ) {
		$output = $aqura_gallery_listing__number = $aqura_gallery_listing__cols = $aqura_gallery_listing__gap = '';

		extract( shortcode_atts( array(
			'aqura_gallery_listing__number'	=> '',
			'aqura_gallery_listing__cols'	=> 'three',
			'aqura_gallery_listing__gap'	=> '0',
		), $atts ) );

		if ( $aqura_gallery_listing__cols == 'one' ) {
			$aqura_gallery_listing__cols = 'col-sm-12';
		} elseif ( $aqura_gallery_listing__cols == 'two' ) {
			$aqura_gallery_listing__cols = 'col-sm-6';
		} elseif ( $aqura_gallery_listing__cols == 'three' ) {
			$aqura_gallery_listing__cols = 'col-sm-4';
		} elseif ( $aqura_gallery_listing__cols == 'four' ) {
			$aqura_gallery_listing__cols = 'col-sm-3';
		} elseif ( $aqura_gallery_listing__cols == 'siz' ) {
			$aqura_gallery_listing__cols = 'col-sm-2';
		}

		global $wp_query;

		$args = array(
			'post_type'		 	=> 'gallery',
			'post_status'	  	=> 'publish',
			'posts_per_page'	=> $aqura_gallery_listing__number,
		);

		$query = new WP_Query($args);

		// Pagination fix
		$temp_query = $wp_query;
		$wp_query	 = NULL;
		$wp_query	 = $query;

		$output .= '<div class="gal-alb-type-1">
						<div class="albums-container">
							<ul class="clearfix">';

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {

				$query->the_post();
				$aqura_gallery_options__thumbnail = rwmb_meta( 'aqura_gallery_options__thumbnail' , array( array( 'limit' => 1 ) , 'size' => 'medium' ));

				if ( !empty($aqura_gallery_options__thumbnail) ) {

					$aqura_gallery_options__thumbnail = reset( $aqura_gallery_options__thumbnail )['url'];

				} else {

					$aqura_gallery_options__thumbnail = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );

				}

				$output .= '<li class="' . esc_attr( $aqura_gallery_listing__cols ) . '" style="padding: ' . esc_attr( $aqura_gallery_listing__gap ) . ' !important;">
								<div class="albums">
									<div class="albums-img" style="background-image: url(' . esc_url( $aqura_gallery_options__thumbnail ) . ');">
										<a href="' . get_the_permalink() . '" class="cover-all"><div class="overlay"></div></a>
									</div>
								</div>
							</li>';

			}

		}

			$output .= '</ul>
					</div>
				</div>';

		wp_reset_query();

		return $output;
	}

}
Aqura_gallery_listing::get_instance();