<?php
if (!function_exists('nano_recent_posts')) {
    function nano_recent_posts($atts)
    {
        $atts = shortcode_atts(array(
            'style'                 => 'list',
            'title'                 => '',
			'order' => 'date',
			'orderby' => 'DESC',
			'custom' => '',
			'post_ids' => '',
			'number' => 3,
            'el_class'              => '',
            'show_cat'              => 'no'
        ), $atts);

        ob_start();
        nano_template_part('shortcode', 'blog-recent-posts' , array('atts' => $atts));
        $output = ob_get_contents();
        ob_end_clean();
        return $output;
    }
}
add_shortcode('blog-recent-posts', 'nano_recent_posts');

add_action('vc_before_init', 'nano_recent_posts_vc');

if (!function_exists('nano_recent_posts_vc')) {
    function nano_recent_posts_vc()
    {
        vc_map(array(
            'name' => __('NA Recent posts', 'nano'),
            'base' => 'blog-recent-posts',
            'category' => __('NA', 'nano'),
            'icon' => 'vc_icon-vc-hoverbox',
            "params" => array(
				array(
					'type' => 'dropdown',
					'heading' => __('Style', 'nano'),
					'param_name' => 'style',
					'value' => array(
						__('List','nano') => 'list',
						__('Slide','nano') =>'slide',
						__('Only Title','nano') =>'only_title',
					)
				),
				array(
                    'type' => 'textfield',
                    'heading' => __('Title', 'nano'),
                    'param_name' => 'title',
                    'admin_label' => true
                ),
				array(
					'type' => 'dropdown',
					'heading' => __('Order', 'nano'),
					'param_name' => 'order',
					'value' => array(
						__('Date','nano') => 'date',
						__('Name','nano') =>'name',
						__('ID','nano') =>'id',
						__('Title','nano') =>'title',
					)
				),
				array(
					'type' => 'dropdown',
					'heading' => __('Order by', 'nano'),
					'param_name' => 'orderby',
					'value' => array(
						__('DESC','nano') =>'desc',
						__('ASC','nano') =>'asc',
					)
				),
				array(
                    'type' => 'textfield',
                    'heading' => __('Number Posts', 'nano'),
                    'param_name' => 'number',
                ),
				array(
					'type' => 'checkbox',
					'heading' => __('Use custom post', 'nano'),
					'param_name' => 'custom',
					'value' => array(
						__('Yes','nano')=>'yes',
					)
				),
				array(
					'type' 			=> 'autocomplete',
					'class' 		=> '',
					'heading' => esc_html__( 'List posts', 'vivavivu' ),
					'param_name' => 'post_ids',
					'settings' 		=> array(
						'multiple' 		=> true,
						'sortable' 		=> true,
						'unique_values' => true,
						'values'		=> list_post_recent_posts(),
					),
					'description' => esc_html__( 'Enter List of posts', 'vivavivu' ),
					'dependency' => array(
						'element' => 'custom',
						'value' => array('yes')
					)
				),
				array(
					'type' => 'checkbox',
					'heading' => __('Category', 'nano'),
					'description' => __('Show Category', 'nano'),
					'param_name' => 'show_cat',
					'value' => array(
						__('Yes','nano')=>'yes',
					)
				),
				
				
            )
        ));
    }
}


















