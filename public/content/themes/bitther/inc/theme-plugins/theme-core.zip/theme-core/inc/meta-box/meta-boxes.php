<?php
if (!class_exists('NA_Meta_Boxes')) {
    class NA_Meta_Boxes
    {
        public $meta_boxes;

        public function __construct()
        {
            $this->add_meta_box_options();
            add_action('admin_init', array($this, 'register'));
        }

        public static function &getInstance()
        {
            static $instance;
            if (!isset($instance)) {
                $instance = new NA_Meta_Boxes();
            }
            return $instance;
        }

        public function add_meta_box_options()
        {
            $meta_boxes = array();
            /* Page Options */
            $meta_boxes[] = array(
                'id'         => 'page_option',
                'title'      => __( 'Page Options', 'bitther' ),
                'pages'      => array( 'page' ), // Post type
                'context'    => 'side',
                'priority'   => 'high',
                'show_names' => true, // Show field names on the left
                'fields'     => array(

                    array(
                        'name'       => __( 'Disable Title', 'bitther' ),
                        'id'         => 'bitther_disable_title',
                        'type'       => 'checkbox',
                        'std'        => 1,
                    ),
                    array(
                        'name'       => __( 'Header layout', 'bitther' ),
                        'id'         => 'layout_header',
                        'type'       => 'select',
                        'options'    => array(
                            'global' => __( 'Use Global', 'bitther' ),
                            'simple' => __( 'Use Simple', 'bitther' ),
                            'center' => __( 'Use Center', 'bitther' ),
                            'left'   => __( 'Use Left', 'bitther' ),
                            'left2'   => __( 'Use Left 2', 'bitther' ),
                        ),
                        'std'  => 'global',
                    ),
                    array(
                        'name'       => __( 'Header Style', 'bitther' ),
                        'id'         => 'style_header',
                        'type'       => 'select',
                        'options'    => array(
                            'global' => __( 'Use Global', 'bitther' ),
                            'style_black' => __( 'Black Style', 'bitther' ),
                            'style_white' => __( 'White Style', 'bitther' ),
                        ),
                        'std'  => 'global',
                    ),

                    array(
                        'name' => __('Logo for  only Pages', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "bitther_logo",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                )
            );
            /* Layout Box */
            /* Banner Meta Box */
            $meta_boxes[] = array(
                'id' => 'banner_meta_box',
                'title' => __('Banner Options', 'bitther'),
                'pages' => array('banner'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Banner Url', 'bitther'),
                        'desc' => __('When click into banner, it will be redirect to this url', 'bitther'),
                        'id' => "na_banner_url",
                        'type' => 'text'
                    ),
                    array(
                        'name' => __('Banner class', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_banner_class",
                        'type' => 'text'
                    ),
                )
            );
            /* Member Meta Box */
            $meta_boxes[] = array(
                'id' => 'member_meta_box',
                'title' => __('Member Options', 'bitther'),
                'pages' => array('member'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Member Image', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_image",
                        'type' => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                    array(
                        'name' => __('Member Position', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_position",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Facebook', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_fb",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Twitter', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_tw",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Instagram', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_isg",
                        'type' => 'text',
                        'std' => '#'
                    ),
                    array(
                        'name' => __('Link Goolge +', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_member_gl",
                        'type' => 'text',
                        'std' => '#'
                    ),
                )
            );

            /* Testimonial Meta Box */
            $meta_boxes[] = array(
                'id' => 'testimonial_meta_box',
                'title' => __('Testimonial Options', 'bitther'),
                'pages' => array('testimonial'),
                'context' => 'normal',
                'fields' => array(
                    array(
                        'name' => __('Image User', 'bitther'),
                        'id' => "na_testimonial_image",
                        'type' => 'image_advanced'
                    ),
                    array(
                        'name' => __('Position', 'bitther'),
                        'desc' => __('', 'bitther'),
                        'id' => "na_testimonial_position",
                        'type' => 'text'
                    ),
                )
            );

            /* Deal Meta Box */
            $meta_boxes[] = array(
                'id' => 'image_bg_meta_box',
                'title' => __('Image Deal Options', 'bitther'),
                'pages' => array( 'product' ),
                'context' => 'normal',
                'fields' => array(

                    // BACKGROUND IMAGE
                    array(
                        'name'  => __('Featured Image For The Deal', 'bitther'),
                        'desc'  => __('The image that will be used as the background , you should use file.png, default size: height=980px,width:246px', 'bitther'),
                        'id'    => "na_image_product",
                        'type'  => 'image_advanced',
                        'max_file_uploads' => 1
                    ),
                )
            );
			
            /* single Meta Box */
            $meta_boxes[] = array(
				'id'         => 'single_metabox',
                'title'      => __( 'Style options', 'bitther' ),
                'pages'      => array( 'post' ), // Post type
                'context'    => 'side',
                'priority'   => 'high',
                'show_names' => true, // Show field names on the left
                'fields'     => array(
					array(
						'name' => __('Style options', 'bitther'),
						'id' => 'style_single',
						'type'       => 'select',
						'options'    => array(
							'' => __( 'Default', 'bitther' ),
							'default' => __( 'Standard', 'bitther' ),
							'single-1' => __( 'Style 1', 'bitther' ),
							'single-2' => __( 'Style 2', 'bitther' ),
							'single-3' => __( 'Style 3', 'bitther' ),
						),
						'std'  => '',
					),
					array(
						'name' => __('Sidebar Layout', 'bitther'),
						'id' => 'sigle_sidebar_layout',
						'type'       => 'select',
						'options'    => array(
							'' => __( 'Default', 'bitther' ),
							'left' => __( 'Left Sidebar', 'bitther' ),
							'right' => __( 'Right Sidebar', 'bitther' ),
							'full' => __( 'Full', 'bitther' ),
						),
						'std'  => '',
					),
				)
			);
			
			
            $this->meta_boxes = $meta_boxes;
        }

        public function register()
        {
            if (class_exists('RW_Meta_Box')) {
                foreach ($this->meta_boxes as $meta_box) {
                    new RW_Meta_Box($meta_box);
                }
            }
        }
    }
}

NA_Meta_Boxes::getInstance();
