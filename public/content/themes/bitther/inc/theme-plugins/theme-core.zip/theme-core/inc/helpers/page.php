<?php
/**
 * Framework  Nano
 * @package     Nano
 * @version     1.0
 * @author      Nanoagency
 * @link        http://www.nanoagency.co
 * @copyright   Copyright (c) 2016 Nanoagency
 * @license     GPL v2
 */
	 if (!function_exists('na_list_page_title_id')) {
		function na_list_page_title_id()
		{
			$page_default = array(
				'none' => 'default',
			);
			$page_id = array();
			$args = array(
				'post_type' => 'page',
				'sort_order' => 'asc',
				'sort_column' => 'post_title',
			);
			$pages = get_pages($args);
			if(!empty($pages)){
				foreach($pages as $v){
					$page_id[$v->post_title] = $v->ID;
				}
				$allpage = array_merge($page_default,$page_id);
				$page_id = array_flip($allpage);
			}
			return $page_id;

		}
	 }
	 add_action('wp_footer', 'action_footer_css');
	 
	 function action_footer_css($css)
        {
            ?>
            <style id="stassets_footer_css">
                <?php echo $css ?>
            </style>
            <?php
        }
	function list_post_recent_posts(){
		
		$argv = array(
            'posts_per_page' => -1,
            'post_type' => 'post',
        );
		$result = array();
		$posts = get_posts($argv);
		if(!empty($posts)){
			foreach ($posts as $post) {
				$result[] = array(
					'value' => $post->ID,
					'label' => $post->ID.' - '.$post->post_title,
				);
			}
		}
			return $result;
		
	}
	
	
	
	
	
	
	
	
	