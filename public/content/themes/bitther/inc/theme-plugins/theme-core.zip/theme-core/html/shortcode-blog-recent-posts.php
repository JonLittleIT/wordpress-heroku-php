<?php
/**
 * The default template for displaying content
 *
 * @author      Nanoliberty
 * @link        http://nanoliberty.co
 * @copyright   Copyright (c) 2015 Nanoliberty
 * @license     GPL v2
 */

$format = get_post_format();
extract($atts);
$args = array(
	'post_type' => 'post',
	'posts_per_page' => $number,
	'order' => $order,
	'orderby' => $orderby,
);
$ids = array();
if($custom =='yes' && !empty($post_ids)){
	$ids = explode(',',$post_ids); 
	$args = array(
		'post_type' => 'post',
		'post__in' => $ids,
		'orderby' => 'post__in',
	);
}
if($style =='only_title'){
	array( 
			'meta_key' => 'post_views_count',
			'posts_per_page' => $number,
			'orderby' => 'meta_value_num',
			'order' => 'ASC',
	);
}
$recent_post = new WP_Query($args); ?>
<div class="recent-post_wrap <?php echo esc_attr($style); ?>">
<?php if(!empty($title)){?><h2 class="widgettitle"><?php echo esc_html($title); ?></h2><?php } ?>
<?php if($style =='list'){
	if ($recent_post->have_posts()):
		while ($recent_post->have_posts()): $recent_post->the_post(); 
		
			?>
			<div class="recent-post disable_cat <?php echo esc_attr($show_cat) ?>">
				<?php na_part_templates('layout/content-sidebar','null',array(
				
				));?>
			</div>
		<?php 
		endwhile;
		wp_reset_postdata();
		endif;
	}elseif($style =='slide'){ ?>
	<div class="recent-post-slider">
	
		<?php if ($recent_post->have_posts()):
			while ($recent_post->have_posts()): $recent_post->the_post(); 
				?>
				<div class="recent-post disable_cat <?php echo esc_attr($show_cat) ?>">
					<?php na_part_templates('layout/content-sidebar','null',array(
					'style' => $style,
					));?>
				</div>
		<?php  endwhile;
		wp_reset_postdata();
		endif; ?>
	</div>
	<?php }elseif($style == 'only_title'){ ?>
		<div class="recent-post disable_cat slider_title only_titles <?php echo esc_attr($show_cat) ?>">
			<?php if ($recent_post->have_posts()):
					while ($recent_post->have_posts()): $recent_post->the_post(); 
						?>
						<div class="trending disable_cat <?php echo esc_attr($show_cat) ?>">
							<?php na_part_templates('layout/content-only-title','null',array(
							
							));?>
						</div>
				<?php  endwhile;
				wp_reset_postdata();
				endif; ?>
		</div>
	<?php } ?>
</div>
