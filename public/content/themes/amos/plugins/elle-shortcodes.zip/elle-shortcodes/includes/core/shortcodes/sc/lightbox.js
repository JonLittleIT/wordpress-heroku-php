scnShortcodeMeta={
	attributes:[
		{
			label:"Image Link",
			id:"image_link",
			isRequired:true
		},
         {
		label:"Video Link (If you want video)",
		id:"video",
		
   		 }  
         
		],
		
		shortcode:"lightbox"
		
};