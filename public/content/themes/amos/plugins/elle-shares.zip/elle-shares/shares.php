<?php
/*
Plugin Name:  Ellethemes Social Shares
Description:  Social Shares functions for WordPress
Version:      1.0.0
Author:       Ellethemes
Author URI:   http://ellethemes.com/
Text Domain:  elle-shares
*/
Class Elle_Shares{
	
     function __construct(){                               

		 $this->google_plus_shares ='<a href="https://plus.google.com/share?url='.get_permalink().'" target="_blank">'; 
		 $this->facebook_shares = '<a href="http://www.facebook.com/sharer.php?u='.get_permalink().'" target="_blank">';
		 $this->twitter_shares = '<a href="http://twitter.com/home?status='.get_the_title().'+'.get_permalink().'" target="_blank">';
		 $this->linkedin_shares = '<a href="http://linkedin.com/shareArticle?mini=true&amp;url='.get_permalink().'&title='.get_the_title().'" target="_blank">';
		 $this->reddit_shares = '<a href="http://reddit.com/submit?url='.get_permalink().'&title='.get_the_title().'" target="_blank">';
		 $this->tumblr_shares = '<a href="http://www.tumblr.com/share/link?url='.get_permalink().'&name='.get_the_title().'" target="_blank">';
		 $this->pinterest_shares ='<a href="http://pinterest.com/pin/create/button/?url='.get_permalink().'&description='.get_the_title().'&media='.wp_get_attachment_url(get_post_thumbnail_id()).'" target="_blank">';
		 $this->digg_shares ='<a href="http://www.digg.com/submit?url='.get_permalink().' " target="_blank">';
		 $this->mail_shares = '<a href="mailto:?subject='.get_the_title().'&body='.get_permalink().'">';

	}



}	