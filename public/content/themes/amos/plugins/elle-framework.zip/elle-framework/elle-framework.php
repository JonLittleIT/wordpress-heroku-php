<?php
/**
 * Plugin Name: Elle Framework
 * Plugin URI: http://ellethemes.com
 * Description: Elle Themes Framework
 * Version: 1.0.0
 * Author: Elle
 * Author URI: http://ellethemes.com
 * License: GPL2
 */
 
 // don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Current version
 */
if ( ! defined( 'ELLE_VERSION' ) ) {

	define( 'ELLE_VERSION', '1.0.0' );
}

class ElleFramework{
    
	    
        public function __construct(){

        	$this->dir = dirname(__FILE__);

        	if(file_exists( get_template_directory(). '/includes/core/amos_metaboxes.php' )){
	    		require_once(get_template_directory().'/includes/core/amos_metaboxes.php');

		    	// The loader will load all of the extensions automatically based on your $redux_opt_name
				require_once($this->dir. '/admin/loader/loader.php');
			}	

	    	/* -------------------- Load Amos Import/Export ------------------ */
		    add_filter( "redux/amos_redata/field/class/codeless_import", array($this, "amos_import_export_load" ));
			

			/* -------------------- End Load Amos Import/Export -------------- */

			if ( !class_exists( 'ReduxFramework' ) && file_exists(  $this->dir. '/admin/framework.php' ) ) {
			    require_once(  $this->dir. '/admin/framework.php' );
			}


			if ( !isset( $redux_demo ) && file_exists( get_template_directory(). '/includes/core/amos_options.php' ) ) {
			    require_once(  get_template_directory(). '/includes/core/amos_options.php' );
			}

			require_once( $this->dir.'/admin/inc/fields/codeless_import/import_export.php');
	    }

	    public function amos_import_export_load($field) {
			    return  $this->dir.'/admin/inc/fields/codeless_import/codeless_import.php'; 
		}
}

new ElleFramework();